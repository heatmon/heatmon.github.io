============================================================
                       HeatMonLib
        Professional CPU Voltage & Temperature Library
                  Documentation (v1.3)
============================================================

Author        : Ari Sohandri Putra/Ari Project
Email         : users.ariproject@gmail.com
Website       : https://heatmon.github.io/HeatMonLib
License Type  : Commercial / Paid Library
Supported OS  : Windows Vista / 7 / 8 / 10 / 11
Framework     : .NET Framework 2.0 or later
============================================================

1. INTRODUCTION
------------------------------------------------------------
HeatMonLib is a professional, paid .NET library for monitoring
CPU voltage and temperature on Windows systems. This library
provides developers with:
  - Per-core data retrieval (clock, voltage, temperature)
  - CPU core count information
  - Estimated CPU voltages in Volts and mV
It is suitable for commercial usage and requires license
activation.

============================================================
2. SYSTEM REQUIREMENTS
------------------------------------------------------------
- Operating System: Windows Vista / 7 / 8 / 10 / 11
- .NET Framework 2.0 or later
- CPU with per-core monitoring support

============================================================
3. GETTING STARTED
------------------------------------------------------------
1. Add a reference to 'HeatMonLib.dll' in your C# project.
2. Import the namespace:
   using HeatMonLib;
3. Initialize the library with your purchased license:
   string userName = "JohnDoe";
   string serialKey = "A1B2C3D4E5F6G7H8I9J0"; // Provided after purchase
   HeatMonLib lib = new HeatMonLib(userName, serialKey);
4. If the license is invalid, an UnauthorizedAccessException
   is thrown.
5. Use the provided APIs to retrieve CPU information.

============================================================
4. KEY FEATURES
------------------------------------------------------------
- Per-core CPU clock monitoring (MHz)
- Estimated CPU voltage monitoring (V / mV)
- Per-core temperature monitoring (°C)
- Retrieve total number of CPU cores
- Lightweight and easy integration in .NET applications
- Supports commercial license

============================================================
5. API REFERENCE
------------------------------------------------------------
1. UpdateAll()
   - Refreshes all CPU monitoring data.
2. GetCpuName()
   - Returns the CPU model name.
3. GetCpuClocks()
   - Returns per-core clock speeds in MHz.
4. GetCpuVoltages()
   - Returns estimated per-core voltages in Volts.
5. GetCpuVoltages_mV()
   - Returns estimated per-core voltages in millivolts.
6. GetCpuTemps()
   - Returns per-core temperatures in Celsius.
7. GetCpuCoreCount()
   - Returns total number of CPU cores.
8. Close()
   - Releases library resources.

============================================================
6. EXAMPLE USAGE
------------------------------------------------------------
using System;
using System.Collections.Generic;
using HeatMonLib;

class Program
{
    static void Main()
    {
        string userName = "JohnDoe";
        string serialKey = "A1B2C3D4E5F6G7H8I9J0";

        try
        {
            HeatMonLib lib = new HeatMonLib(userName, serialKey);

            Console.WriteLine("CPU: " + lib.GetCpuName());
            Console.WriteLine("Cores: " + lib.GetCpuCoreCount());

            List<float> clocks = lib.GetCpuClocks();
            List<double> volts = lib.GetCpuVoltages();
            List<float> temps = lib.GetCpuTemps();

            for (int i = 0; i < clocks.Count; i++)
            {
                Console.WriteLine($"Core {i}: {clocks[i]} MHz | {volts[i]:F2} V | {temps[i]} °C");
            }

            lib.Close();
        }
        catch (UnauthorizedAccessException ex)
        {
            Console.WriteLine("License error: " + ex.Message);
        }
    }
}

============================================================
7. LICENSE AND REGISTRATION
------------------------------------------------------------
HeatMonLib is a commercial, paid library. By default, it does
not function without a valid purchased license.

- Personal Use: Trial or development only
- Commercial Use: Requires registration with a valid serial key

Registration Steps:
1. Purchase a commercial license via email:
   users.ariproject@gmail.com
2. Receive your license key
3. Initialize the library with your name and serial key
4. Upon successful validation, the library is fully unlocked
   for commercial usage

Example Serial Key Format: XXX-XXX-XXX-XXX

============================================================
8. TROUBLESHOOTING
------------------------------------------------------------
- No CPU data?
  Ensure your CPU supports per-core monitoring.

- Library throws an exception?
  Verify the serial key is correct.

- Application terminates unexpectedly?
  Run the program with administrator privileges.

============================================================
9. PURCHASE & SUPPORT
------------------------------------------------------------
For purchasing a commercial license or technical support:
Email: users.ariproject@gmail.com

============================================================
END OF DOCUMENTATION
============================================================