﻿Imports System
Imports System.Text
Imports System.Security.Cryptography
Imports System.Windows.Forms   ' 🔹 Perlu reference ke System.Windows.Forms.dll

Module LicenseGen
    Sub Main()
        Console.Write("Masukkan nama: ")
        Dim name As String = Console.ReadLine()

        Dim serial As String = GenerateHash(name)

        Console.WriteLine("Nama   : " & name)
        Console.WriteLine("Serial : " & serial)

        ' 🔹 Auto copy ke clipboard dalam format kode
        Dim clipText As String = "Dim yourvariable As New HeatMonLib.HeatMonLib(""" & name & """, """ & serial & """)"
        Clipboard.SetText(clipText)

        Console.WriteLine()
        Console.WriteLine("✅ Kode berikut sudah dicopy ke clipboard:")
        Console.WriteLine(clipText)
        Console.ReadLine()
    End Sub

    Private Function GenerateHash(ByVal inputText As String) As String
        Dim bytes() As Byte = Encoding.UTF8.GetBytes(inputText)
        Dim sha As New SHA256Managed()
        Dim hash() As Byte = sha.ComputeHash(bytes)

        Dim sb As New StringBuilder()
        For Each b As Byte In hash
            sb.Append(b.ToString("X2"))
        Next

        Return sb.ToString().Substring(0, 20)
    End Function
End Module
