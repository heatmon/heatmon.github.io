﻿Imports System
Imports System.Text
Imports System.Security.Cryptography
Imports OpenHardwareMonitor.Hardware

Public Class HeatMonLib
    Private computer As Computer
    Private userName As String
    Private serialKey As String

    ' 🔹 Constructor dengan Nama + Serial
    Public Sub New(ByVal name As String, ByVal serial As String)
        If Not ValidateLicense(name, serial) Then
            Throw New UnauthorizedAccessException("Invalid license. Please contact the developer.")
        End If

        Me.userName = name
        Me.serialKey = serial

        computer = New Computer()
        computer.CPUEnabled = True
        computer.Open()
    End Sub

    ' 🔹 Validasi (serial = SHA256(name).Substring(0,20))
    Private Function ValidateLicense(ByVal name As String, ByVal serial As String) As Boolean
        If String.IsNullOrEmpty(name) OrElse String.IsNullOrEmpty(serial) Then
            Return False
        End If

        Dim expected As String = InternalHash(name)
        Return String.Equals(expected, serial, StringComparison.OrdinalIgnoreCase)
    End Function

    ' 🔹 Hash internal (SHA-256, potong 20 karakter)
    Private Function InternalHash(ByVal inputText As String) As String
        Dim bytes() As Byte = Encoding.UTF8.GetBytes(inputText)
        Dim sha As New SHA256Managed()
        Dim hash() As Byte = sha.ComputeHash(bytes)

        Dim sb As New StringBuilder()
        For Each b As Byte In hash
            sb.Append(b.ToString("X2"))
        Next

        ' ambil 20 karakter awal
        Return sb.ToString().Substring(0, 20)
    End Function

    ' ============================================================
    ' 🔹 CPU Monitoring (sama seperti sebelumnya)
    ' ============================================================
    Private Sub UpdateAll(hw As IHardware)
        hw.Update()
        For Each subhw As IHardware In hw.SubHardware
            UpdateAll(subhw)
        Next
    End Sub

    Public Sub UpdateAll()
        If computer IsNot Nothing Then
            For Each dev As IHardware In computer.Hardware
                UpdateAll(dev)
            Next
        End If
    End Sub

    Public Function GetCpuName() As String
        For Each hw As IHardware In computer.Hardware
            If hw.HardwareType = HardwareType.CPU Then
                Return hw.Name
            End If
        Next
        Return "N/A"
    End Function

    ' 🔹 Ambil clock per core (MHz)
    Public Function GetCpuClocks() As List(Of Single)
        Dim clocks As New List(Of Single)
        For Each hw As IHardware In computer.Hardware
            If hw.HardwareType = HardwareType.CPU Then
                UpdateAll(hw)
                For Each sensor In hw.Sensors
                    If sensor.SensorType = SensorType.Clock AndAlso sensor.Name.ToLower().Contains("core") Then
                        clocks.Add(sensor.Value.GetValueOrDefault())
                    End If
                Next
            End If
        Next
        Return clocks
    End Function

    ' 🔹 Konversi clock MHz → Volt
    Private Function ClockToVolt(clockMHz As Double) As Double
        Dim Fmin As Double = 800    ' MHz
        Dim Fmax As Double = 5000   ' MHz
        Dim Vmin As Double = 0.7    ' Volt
        Dim Vmax As Double = 1.4    ' Volt

        If clockMHz < Fmin Then clockMHz = Fmin
        If clockMHz > Fmax Then clockMHz = Fmax

        Return Vmin + (clockMHz - Fmin) / (Fmax - Fmin) * (Vmax - Vmin)
    End Function

    ' 🔹 Ambil voltase hasil konversi dari clock
    Public Function GetCpuVoltages() As List(Of Double)
        Dim volts As New List(Of Double)
        For Each mhz In GetCpuClocks()
            volts.Add(ClockToVolt(mhz))
        Next
        Return volts
    End Function

    Public Function GetCpuVoltages_mV() As List(Of Double)
        Dim mvolts As New List(Of Double)
        For Each mhz In GetCpuClocks()
            mvolts.Add(ClockToVolt(mhz) * 1000)
        Next
        Return mvolts
    End Function

    ' 🔹 Ambil suhu per core
    Public Function GetCpuTemps() As List(Of Single)
        Dim temps As New List(Of Single)
        For Each hw As IHardware In computer.Hardware
            If hw.HardwareType = HardwareType.CPU Then
                UpdateAll(hw)
                For Each sensor In hw.Sensors
                    If sensor.SensorType = SensorType.Temperature AndAlso sensor.Name.ToLower().Contains("core") Then
                        temps.Add(sensor.Value.GetValueOrDefault())
                    End If
                Next
            End If
        Next
        Return temps
    End Function

    Public Function GetCpuCoreCount() As Integer
        Return GetCpuClocks().Count
    End Function

    Public Sub Close()
        If computer IsNot Nothing Then
            computer.Close()
            computer = Nothing
        End If
    End Sub
End Class
