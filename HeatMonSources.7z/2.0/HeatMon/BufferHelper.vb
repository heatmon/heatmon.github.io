﻿Imports System.Runtime.InteropServices
Imports System.Reflection

Public Class BufferHelper

    ' === Opsional: hanya kalau mau pakai WS_EX_COMPOSITED ===
    Private Const WS_EX_COMPOSITED As Integer = &H2000000
    Private Const GWL_EXSTYLE As Integer = -20

    <DllImport("user32.dll", CharSet:=CharSet.Auto)>
    Private Shared Function GetWindowLong(ByVal hWnd As IntPtr, ByVal nIndex As Integer) As Integer
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto)>
    Private Shared Function SetWindowLong(ByVal hWnd As IntPtr, ByVal nIndex As Integer, ByVal dwNewLong As Integer) As Integer
    End Function


    ' === Versi lebih ringan: pakai SetStyle / reflection ===
    Public Shared Sub EnableDoubleBuffering(ctrl As Control)
        If ctrl Is Nothing Then Return

        ' Kalau control support gaya control (misalnya Panel, Form, UserControl)
        Dim propInfo = ctrl.GetType().GetProperty("DoubleBuffered", BindingFlags.NonPublic Or BindingFlags.Instance)
        If propInfo IsNot Nothing Then
            propInfo.SetValue(ctrl, True, Nothing)
        End If

        ' Tambahkan ke semua child control
        For Each child As Control In ctrl.Controls
            EnableDoubleBuffering(child)
        Next
    End Sub

    ' === Opsional: Kalau mau global pakai WS_EX_COMPOSITED untuk parent Form saja ===
    Public Shared Sub EnableFormComposited(form As Form)
        If form Is Nothing Then Return
        Try
            Dim style As Integer = GetWindowLong(form.Handle, GWL_EXSTYLE)
            style = style Or WS_EX_COMPOSITED
            SetWindowLong(form.Handle, GWL_EXSTYLE, style)
        Catch
            ' Abaikan kalau gagal
        End Try
    End Sub

End Class
