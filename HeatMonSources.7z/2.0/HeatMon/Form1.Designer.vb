﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.refreshTimer = New System.Windows.Forms.Timer(Me.components)
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveReportTXTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveGraphPNGToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowGraphToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.GraphThemesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DarkBlueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SlateGrayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TealDefaultToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MidnightPurpleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EmeraldGreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FireOrangeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OceanBlueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SteelGrayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SunsetPinkToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GoldBrownToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CyanTealToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SilverToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ShowUnlistedCoreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StayOnTopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.EnterSerialKeyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TimerUI = New System.Windows.Forms.Timer(Me.components)
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.lblRPM = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.GradientLabel3 = New HeatMon.GradientLabel()
        Me.Label3 = New HeatMon.GradientLabel()
        Me.lblCpuName = New HeatMon.GradientLabel()
        Me.GradientLabel2 = New HeatMon.GradientLabel()
        Me.GradientLabel1 = New HeatMon.GradientLabel()
        Me.Label5 = New HeatMon.GradientLabel()
        Me.Label4 = New HeatMon.GradientLabel()
        Me.temp24 = New HeatMon.GradientLabel()
        Me.temp23 = New HeatMon.GradientLabel()
        Me.temp22 = New HeatMon.GradientLabel()
        Me.temp21 = New HeatMon.GradientLabel()
        Me.temp20 = New HeatMon.GradientLabel()
        Me.temp19 = New HeatMon.GradientLabel()
        Me.temp18 = New HeatMon.GradientLabel()
        Me.temp17 = New HeatMon.GradientLabel()
        Me.temp16 = New HeatMon.GradientLabel()
        Me.temp15 = New HeatMon.GradientLabel()
        Me.temp14 = New HeatMon.GradientLabel()
        Me.temp13 = New HeatMon.GradientLabel()
        Me.temp12 = New HeatMon.GradientLabel()
        Me.temp11 = New HeatMon.GradientLabel()
        Me.temp10 = New HeatMon.GradientLabel()
        Me.temp9 = New HeatMon.GradientLabel()
        Me.temp8 = New HeatMon.GradientLabel()
        Me.temp7 = New HeatMon.GradientLabel()
        Me.temp6 = New HeatMon.GradientLabel()
        Me.temp5 = New HeatMon.GradientLabel()
        Me.temp3 = New HeatMon.GradientLabel()
        Me.temp4 = New HeatMon.GradientLabel()
        Me.temp2 = New HeatMon.GradientLabel()
        Me.temp1 = New HeatMon.GradientLabel()
        Me.clock24 = New HeatMon.GradientLabel()
        Me.clock23 = New HeatMon.GradientLabel()
        Me.clock22 = New HeatMon.GradientLabel()
        Me.clock21 = New HeatMon.GradientLabel()
        Me.clock20 = New HeatMon.GradientLabel()
        Me.clock19 = New HeatMon.GradientLabel()
        Me.clock18 = New HeatMon.GradientLabel()
        Me.clock17 = New HeatMon.GradientLabel()
        Me.clock16 = New HeatMon.GradientLabel()
        Me.clock15 = New HeatMon.GradientLabel()
        Me.clock14 = New HeatMon.GradientLabel()
        Me.clock13 = New HeatMon.GradientLabel()
        Me.clock12 = New HeatMon.GradientLabel()
        Me.clock11 = New HeatMon.GradientLabel()
        Me.clock10 = New HeatMon.GradientLabel()
        Me.clock9 = New HeatMon.GradientLabel()
        Me.clock8 = New HeatMon.GradientLabel()
        Me.clock7 = New HeatMon.GradientLabel()
        Me.clock6 = New HeatMon.GradientLabel()
        Me.clock5 = New HeatMon.GradientLabel()
        Me.clock4 = New HeatMon.GradientLabel()
        Me.clock3 = New HeatMon.GradientLabel()
        Me.clock2 = New HeatMon.GradientLabel()
        Me.clock1 = New HeatMon.GradientLabel()
        Me.core24 = New HeatMon.GradientLabel()
        Me.core23 = New HeatMon.GradientLabel()
        Me.core22 = New HeatMon.GradientLabel()
        Me.core21 = New HeatMon.GradientLabel()
        Me.core20 = New HeatMon.GradientLabel()
        Me.core19 = New HeatMon.GradientLabel()
        Me.core18 = New HeatMon.GradientLabel()
        Me.core17 = New HeatMon.GradientLabel()
        Me.core16 = New HeatMon.GradientLabel()
        Me.core15 = New HeatMon.GradientLabel()
        Me.core14 = New HeatMon.GradientLabel()
        Me.core13 = New HeatMon.GradientLabel()
        Me.core12 = New HeatMon.GradientLabel()
        Me.core11 = New HeatMon.GradientLabel()
        Me.core10 = New HeatMon.GradientLabel()
        Me.core9 = New HeatMon.GradientLabel()
        Me.core8 = New HeatMon.GradientLabel()
        Me.core7 = New HeatMon.GradientLabel()
        Me.core6 = New HeatMon.GradientLabel()
        Me.core5 = New HeatMon.GradientLabel()
        Me.core4 = New HeatMon.GradientLabel()
        Me.core3 = New HeatMon.GradientLabel()
        Me.core2 = New HeatMon.GradientLabel()
        Me.core1 = New HeatMon.GradientLabel()
        Me.GradientLabel4 = New HeatMon.GradientLabel()
        Me.GradientLabel5 = New HeatMon.GradientLabel()
        Me.Panel1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'CheckBox1
        '
        Me.CheckBox1.BackColor = System.Drawing.Color.White
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.CheckBox1.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.Location = New System.Drawing.Point(109, 170)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(49, 18)
        Me.CheckBox1.TabIndex = 50
        Me.CheckBox1.Text = "mV"
        Me.CheckBox1.UseVisualStyleBackColor = False
        '
        'CheckBox2
        '
        Me.CheckBox2.BackColor = System.Drawing.Color.White
        Me.CheckBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.CheckBox2.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox2.Location = New System.Drawing.Point(151, 170)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(45, 18)
        Me.CheckBox2.TabIndex = 51
        Me.CheckBox2.Text = "Volt"
        Me.CheckBox2.UseVisualStyleBackColor = False
        '
        'CheckBox3
        '
        Me.CheckBox3.BackColor = System.Drawing.Color.White
        Me.CheckBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.CheckBox3.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox3.Location = New System.Drawing.Point(265, 170)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(36, 18)
        Me.CheckBox3.TabIndex = 53
        Me.CheckBox3.Text = "°F"
        Me.CheckBox3.UseVisualStyleBackColor = False
        '
        'CheckBox4
        '
        Me.CheckBox4.BackColor = System.Drawing.Color.White
        Me.CheckBox4.Checked = True
        Me.CheckBox4.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.CheckBox4.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox4.Location = New System.Drawing.Point(223, 170)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(36, 18)
        Me.CheckBox4.TabIndex = 52
        Me.CheckBox4.Text = "°C"
        Me.CheckBox4.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel1.AutoScroll = True
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.temp24)
        Me.Panel1.Controls.Add(Me.temp23)
        Me.Panel1.Controls.Add(Me.temp22)
        Me.Panel1.Controls.Add(Me.temp21)
        Me.Panel1.Controls.Add(Me.temp20)
        Me.Panel1.Controls.Add(Me.temp19)
        Me.Panel1.Controls.Add(Me.temp18)
        Me.Panel1.Controls.Add(Me.temp17)
        Me.Panel1.Controls.Add(Me.temp16)
        Me.Panel1.Controls.Add(Me.temp15)
        Me.Panel1.Controls.Add(Me.temp14)
        Me.Panel1.Controls.Add(Me.temp13)
        Me.Panel1.Controls.Add(Me.temp12)
        Me.Panel1.Controls.Add(Me.temp11)
        Me.Panel1.Controls.Add(Me.temp10)
        Me.Panel1.Controls.Add(Me.temp9)
        Me.Panel1.Controls.Add(Me.temp8)
        Me.Panel1.Controls.Add(Me.temp7)
        Me.Panel1.Controls.Add(Me.temp6)
        Me.Panel1.Controls.Add(Me.temp5)
        Me.Panel1.Controls.Add(Me.temp3)
        Me.Panel1.Controls.Add(Me.temp4)
        Me.Panel1.Controls.Add(Me.temp2)
        Me.Panel1.Controls.Add(Me.temp1)
        Me.Panel1.Controls.Add(Me.clock24)
        Me.Panel1.Controls.Add(Me.clock23)
        Me.Panel1.Controls.Add(Me.clock22)
        Me.Panel1.Controls.Add(Me.clock21)
        Me.Panel1.Controls.Add(Me.clock20)
        Me.Panel1.Controls.Add(Me.clock19)
        Me.Panel1.Controls.Add(Me.clock18)
        Me.Panel1.Controls.Add(Me.clock17)
        Me.Panel1.Controls.Add(Me.clock16)
        Me.Panel1.Controls.Add(Me.clock15)
        Me.Panel1.Controls.Add(Me.clock14)
        Me.Panel1.Controls.Add(Me.clock13)
        Me.Panel1.Controls.Add(Me.clock12)
        Me.Panel1.Controls.Add(Me.clock11)
        Me.Panel1.Controls.Add(Me.clock10)
        Me.Panel1.Controls.Add(Me.clock9)
        Me.Panel1.Controls.Add(Me.clock8)
        Me.Panel1.Controls.Add(Me.clock7)
        Me.Panel1.Controls.Add(Me.clock6)
        Me.Panel1.Controls.Add(Me.clock5)
        Me.Panel1.Controls.Add(Me.clock4)
        Me.Panel1.Controls.Add(Me.clock3)
        Me.Panel1.Controls.Add(Me.clock2)
        Me.Panel1.Controls.Add(Me.clock1)
        Me.Panel1.Controls.Add(Me.core24)
        Me.Panel1.Controls.Add(Me.core23)
        Me.Panel1.Controls.Add(Me.core22)
        Me.Panel1.Controls.Add(Me.core21)
        Me.Panel1.Controls.Add(Me.core20)
        Me.Panel1.Controls.Add(Me.core19)
        Me.Panel1.Controls.Add(Me.core18)
        Me.Panel1.Controls.Add(Me.core17)
        Me.Panel1.Controls.Add(Me.core16)
        Me.Panel1.Controls.Add(Me.core15)
        Me.Panel1.Controls.Add(Me.core14)
        Me.Panel1.Controls.Add(Me.core13)
        Me.Panel1.Controls.Add(Me.core12)
        Me.Panel1.Controls.Add(Me.core11)
        Me.Panel1.Controls.Add(Me.core10)
        Me.Panel1.Controls.Add(Me.core9)
        Me.Panel1.Controls.Add(Me.core8)
        Me.Panel1.Controls.Add(Me.core7)
        Me.Panel1.Controls.Add(Me.core6)
        Me.Panel1.Controls.Add(Me.core5)
        Me.Panel1.Controls.Add(Me.core4)
        Me.Panel1.Controls.Add(Me.core3)
        Me.Panel1.Controls.Add(Me.core2)
        Me.Panel1.Controls.Add(Me.core1)
        Me.Panel1.Location = New System.Drawing.Point(10, 192)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(327, 172)
        Me.Panel1.TabIndex = 72
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.Control
        Me.MenuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ViewToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.MenuStrip1.Size = New System.Drawing.Size(343, 24)
        Me.MenuStrip1.TabIndex = 79
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveReportTXTToolStripMenuItem, Me.SaveGraphPNGToolStripMenuItem, Me.ToolStripSeparator1, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'SaveReportTXTToolStripMenuItem
        '
        Me.SaveReportTXTToolStripMenuItem.Image = Global.HeatMon.My.Resources.Resources.icons8_save_16
        Me.SaveReportTXTToolStripMenuItem.Name = "SaveReportTXTToolStripMenuItem"
        Me.SaveReportTXTToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SaveReportTXTToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.SaveReportTXTToolStripMenuItem.Text = "Save Report .TXT"
        '
        'SaveGraphPNGToolStripMenuItem
        '
        Me.SaveGraphPNGToolStripMenuItem.Enabled = False
        Me.SaveGraphPNGToolStripMenuItem.Image = Global.HeatMon.My.Resources.Resources.icons8_graph_16
        Me.SaveGraphPNGToolStripMenuItem.Name = "SaveGraphPNGToolStripMenuItem"
        Me.SaveGraphPNGToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Alt) _
            Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SaveGraphPNGToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.SaveGraphPNGToolStripMenuItem.Text = "Save Graph .PNG"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(223, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShowGraphToolStripMenuItem, Me.ToolStripSeparator2, Me.GraphThemesToolStripMenuItem, Me.ToolStripSeparator4, Me.ShowUnlistedCoreToolStripMenuItem, Me.StayOnTopToolStripMenuItem})
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.ViewToolStripMenuItem.Text = "&View"
        '
        'ShowGraphToolStripMenuItem
        '
        Me.ShowGraphToolStripMenuItem.Name = "ShowGraphToolStripMenuItem"
        Me.ShowGraphToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.G), System.Windows.Forms.Keys)
        Me.ShowGraphToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.ShowGraphToolStripMenuItem.Text = "Show Graph"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(184, 6)
        '
        'GraphThemesToolStripMenuItem
        '
        Me.GraphThemesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DarkBlueToolStripMenuItem, Me.SlateGrayToolStripMenuItem, Me.TealDefaultToolStripMenuItem, Me.MidnightPurpleToolStripMenuItem, Me.EmeraldGreenToolStripMenuItem, Me.FireOrangeToolStripMenuItem, Me.OceanBlueToolStripMenuItem, Me.SteelGrayToolStripMenuItem, Me.SunsetPinkToolStripMenuItem, Me.GoldBrownToolStripMenuItem, Me.CyanTealToolStripMenuItem, Me.SilverToolStripMenuItem})
        Me.GraphThemesToolStripMenuItem.Enabled = False
        Me.GraphThemesToolStripMenuItem.Image = Global.HeatMon.My.Resources.Resources.palette
        Me.GraphThemesToolStripMenuItem.Name = "GraphThemesToolStripMenuItem"
        Me.GraphThemesToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.GraphThemesToolStripMenuItem.Text = "Graph Themes"
        '
        'DarkBlueToolStripMenuItem
        '
        Me.DarkBlueToolStripMenuItem.Checked = True
        Me.DarkBlueToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.DarkBlueToolStripMenuItem.Name = "DarkBlueToolStripMenuItem"
        Me.DarkBlueToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.DarkBlueToolStripMenuItem.Text = "Dark blue"
        '
        'SlateGrayToolStripMenuItem
        '
        Me.SlateGrayToolStripMenuItem.Name = "SlateGrayToolStripMenuItem"
        Me.SlateGrayToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.SlateGrayToolStripMenuItem.Text = "Slate gray"
        '
        'TealDefaultToolStripMenuItem
        '
        Me.TealDefaultToolStripMenuItem.Name = "TealDefaultToolStripMenuItem"
        Me.TealDefaultToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.TealDefaultToolStripMenuItem.Text = "Teal"
        '
        'MidnightPurpleToolStripMenuItem
        '
        Me.MidnightPurpleToolStripMenuItem.Name = "MidnightPurpleToolStripMenuItem"
        Me.MidnightPurpleToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.MidnightPurpleToolStripMenuItem.Text = "Midnight Purple"
        '
        'EmeraldGreenToolStripMenuItem
        '
        Me.EmeraldGreenToolStripMenuItem.Name = "EmeraldGreenToolStripMenuItem"
        Me.EmeraldGreenToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.EmeraldGreenToolStripMenuItem.Text = "Emerald Green"
        '
        'FireOrangeToolStripMenuItem
        '
        Me.FireOrangeToolStripMenuItem.Name = "FireOrangeToolStripMenuItem"
        Me.FireOrangeToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.FireOrangeToolStripMenuItem.Text = "Fire Orange"
        '
        'OceanBlueToolStripMenuItem
        '
        Me.OceanBlueToolStripMenuItem.Name = "OceanBlueToolStripMenuItem"
        Me.OceanBlueToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.OceanBlueToolStripMenuItem.Text = "Ocean Blue"
        '
        'SteelGrayToolStripMenuItem
        '
        Me.SteelGrayToolStripMenuItem.Name = "SteelGrayToolStripMenuItem"
        Me.SteelGrayToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.SteelGrayToolStripMenuItem.Text = "Steel Gray"
        '
        'SunsetPinkToolStripMenuItem
        '
        Me.SunsetPinkToolStripMenuItem.Name = "SunsetPinkToolStripMenuItem"
        Me.SunsetPinkToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.SunsetPinkToolStripMenuItem.Text = "Sunset Pink"
        '
        'GoldBrownToolStripMenuItem
        '
        Me.GoldBrownToolStripMenuItem.Name = "GoldBrownToolStripMenuItem"
        Me.GoldBrownToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.GoldBrownToolStripMenuItem.Text = "Gold Brown"
        '
        'CyanTealToolStripMenuItem
        '
        Me.CyanTealToolStripMenuItem.Name = "CyanTealToolStripMenuItem"
        Me.CyanTealToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.CyanTealToolStripMenuItem.Text = "Cyan Teal"
        '
        'SilverToolStripMenuItem
        '
        Me.SilverToolStripMenuItem.Name = "SilverToolStripMenuItem"
        Me.SilverToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.SilverToolStripMenuItem.Text = "Silver"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(184, 6)
        '
        'ShowUnlistedCoreToolStripMenuItem
        '
        Me.ShowUnlistedCoreToolStripMenuItem.Checked = True
        Me.ShowUnlistedCoreToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ShowUnlistedCoreToolStripMenuItem.Name = "ShowUnlistedCoreToolStripMenuItem"
        Me.ShowUnlistedCoreToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.ShowUnlistedCoreToolStripMenuItem.Text = "Show Unlisted Core #"
        '
        'StayOnTopToolStripMenuItem
        '
        Me.StayOnTopToolStripMenuItem.Name = "StayOnTopToolStripMenuItem"
        Me.StayOnTopToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.StayOnTopToolStripMenuItem.Text = "Stay On Top"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContentToolStripMenuItem, Me.AboutToolStripMenuItem, Me.ToolStripSeparator3, Me.EnterSerialKeyToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'ContentToolStripMenuItem
        '
        Me.ContentToolStripMenuItem.Image = Global.HeatMon.My.Resources.Resources.whois
        Me.ContentToolStripMenuItem.Name = "ContentToolStripMenuItem"
        Me.ContentToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.ContentToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.ContentToolStripMenuItem.Text = "Content"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(151, 6)
        '
        'EnterSerialKeyToolStripMenuItem
        '
        Me.EnterSerialKeyToolStripMenuItem.Name = "EnterSerialKeyToolStripMenuItem"
        Me.EnterSerialKeyToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.EnterSerialKeyToolStripMenuItem.Text = "&Enter Serial Key"
        '
        'TimerUI
        '
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.Control
        Me.Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), System.Drawing.Image)
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.Enabled = False
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.Image = Global.HeatMon.My.Resources.Resources.icons8_graph_16
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button2.Location = New System.Drawing.Point(99, 32)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(83, 40)
        Me.Button2.TabIndex = 78
        Me.Button2.TabStop = False
        Me.Button2.Text = "Save Graph"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Control
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Image = Global.HeatMon.My.Resources.Resources.icons8_save_16
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button1.Location = New System.Drawing.Point(10, 32)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(83, 40)
        Me.Button1.TabIndex = 77
        Me.Button1.TabStop = False
        Me.Button1.Text = "Save Data"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Panel2.BackgroundImage = Global.HeatMon.My.Resources.Resources.barbackyellow
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.Controls.Add(Me.lblRPM)
        Me.Panel2.Location = New System.Drawing.Point(188, 32)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(125, 40)
        Me.Panel2.TabIndex = 75
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 17)
        Me.Label2.TabIndex = 75
        Me.Label2.Text = "FAN Speed"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox2.Image = Global.HeatMon.My.Resources.Resources.fanning
        Me.PictureBox2.Location = New System.Drawing.Point(86, 3)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(32, 32)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 74
        Me.PictureBox2.TabStop = False
        '
        'lblRPM
        '
        Me.lblRPM.BackColor = System.Drawing.Color.Transparent
        Me.lblRPM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRPM.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRPM.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblRPM.Location = New System.Drawing.Point(5, 17)
        Me.lblRPM.Name = "lblRPM"
        Me.lblRPM.Size = New System.Drawing.Size(75, 17)
        Me.lblRPM.TabIndex = 73
        Me.lblRPM.Text = "..."
        Me.lblRPM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Location = New System.Drawing.Point(343, 32)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(0, 332)
        Me.PictureBox1.TabIndex = 71
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Visible = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 367)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(343, 22)
        Me.StatusStrip1.TabIndex = 93
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Enabled = False
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(240, 17)
        Me.ToolStripStatusLabel1.Text = "© 2018 - 2025 Ari Project. All Rights Reserved."
        '
        'GradientLabel3
        '
        Me.GradientLabel3.ForeColor = System.Drawing.Color.Blue
        Me.GradientLabel3.GradientColor1 = System.Drawing.Color.White
        Me.GradientLabel3.GradientColor2 = System.Drawing.SystemColors.ButtonHighlight
        Me.GradientLabel3.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.GradientLabel3.Location = New System.Drawing.Point(10, 152)
        Me.GradientLabel3.Name = "GradientLabel3"
        Me.GradientLabel3.Size = New System.Drawing.Size(83, 40)
        Me.GradientLabel3.TabIndex = 90
        Me.GradientLabel3.Text = "Core #"
        Me.GradientLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.ForeColor = System.Drawing.Color.Blue
        Me.Label3.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.Label3.GradientColor2 = System.Drawing.Color.White
        Me.Label3.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.Label3.Location = New System.Drawing.Point(202, 115)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(113, 37)
        Me.Label3.TabIndex = 89
        Me.Label3.Text = "..."
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblCpuName
        '
        Me.lblCpuName.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.lblCpuName.GradientColor2 = System.Drawing.Color.White
        Me.lblCpuName.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.lblCpuName.Location = New System.Drawing.Point(45, 115)
        Me.lblCpuName.Name = "lblCpuName"
        Me.lblCpuName.Size = New System.Drawing.Size(157, 37)
        Me.lblCpuName.TabIndex = 88
        Me.lblCpuName.Text = "..."
        Me.lblCpuName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GradientLabel2
        '
        Me.GradientLabel2.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.GradientLabel2.GradientColor2 = System.Drawing.Color.White
        Me.GradientLabel2.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.GradientLabel2.Image = Global.HeatMon.My.Resources.Resources.cpu
        Me.GradientLabel2.Location = New System.Drawing.Point(10, 115)
        Me.GradientLabel2.Name = "GradientLabel2"
        Me.GradientLabel2.Size = New System.Drawing.Size(35, 37)
        Me.GradientLabel2.TabIndex = 87
        Me.GradientLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GradientLabel1
        '
        Me.GradientLabel1.GradientColor1 = System.Drawing.Color.White
        Me.GradientLabel1.GradientColor2 = System.Drawing.Color.Gainsboro
        Me.GradientLabel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.GradientLabel1.Image = Global.HeatMon.My.Resources.Resources.computer
        Me.GradientLabel1.Location = New System.Drawing.Point(10, 78)
        Me.GradientLabel1.Name = "GradientLabel1"
        Me.GradientLabel1.Size = New System.Drawing.Size(35, 37)
        Me.GradientLabel1.TabIndex = 86
        Me.GradientLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.ForeColor = System.Drawing.Color.Blue
        Me.Label5.GradientColor1 = System.Drawing.Color.White
        Me.Label5.GradientColor2 = System.Drawing.Color.Gainsboro
        Me.Label5.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.Label5.Location = New System.Drawing.Point(202, 78)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(113, 37)
        Me.Label5.TabIndex = 85
        Me.Label5.Text = "..."
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.GradientColor1 = System.Drawing.Color.White
        Me.Label4.GradientColor2 = System.Drawing.Color.Gainsboro
        Me.Label4.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.Label4.Location = New System.Drawing.Point(45, 78)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(157, 37)
        Me.Label4.TabIndex = 84
        Me.Label4.Text = "..."
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'temp24
        '
        Me.temp24.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp24.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp24.GradientColor2 = System.Drawing.Color.White
        Me.temp24.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp24.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp24.Location = New System.Drawing.Point(192, 506)
        Me.temp24.Name = "temp24"
        Me.temp24.Size = New System.Drawing.Size(113, 22)
        Me.temp24.TabIndex = 165
        Me.temp24.Text = "<None>"
        Me.temp24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp24.Visible = False
        '
        'temp23
        '
        Me.temp23.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp23.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp23.GradientColor2 = System.Drawing.Color.White
        Me.temp23.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp23.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp23.Location = New System.Drawing.Point(192, 484)
        Me.temp23.Name = "temp23"
        Me.temp23.Size = New System.Drawing.Size(113, 22)
        Me.temp23.TabIndex = 164
        Me.temp23.Text = "<None>"
        Me.temp23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp23.Visible = False
        '
        'temp22
        '
        Me.temp22.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp22.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp22.GradientColor2 = System.Drawing.Color.White
        Me.temp22.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp22.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp22.Location = New System.Drawing.Point(192, 462)
        Me.temp22.Name = "temp22"
        Me.temp22.Size = New System.Drawing.Size(113, 22)
        Me.temp22.TabIndex = 163
        Me.temp22.Text = "<None>"
        Me.temp22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp22.Visible = False
        '
        'temp21
        '
        Me.temp21.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp21.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp21.GradientColor2 = System.Drawing.Color.White
        Me.temp21.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp21.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp21.Location = New System.Drawing.Point(192, 440)
        Me.temp21.Name = "temp21"
        Me.temp21.Size = New System.Drawing.Size(113, 22)
        Me.temp21.TabIndex = 162
        Me.temp21.Text = "<None>"
        Me.temp21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp21.Visible = False
        '
        'temp20
        '
        Me.temp20.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp20.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp20.GradientColor2 = System.Drawing.Color.White
        Me.temp20.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp20.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp20.Location = New System.Drawing.Point(192, 418)
        Me.temp20.Name = "temp20"
        Me.temp20.Size = New System.Drawing.Size(113, 22)
        Me.temp20.TabIndex = 161
        Me.temp20.Text = "<None>"
        Me.temp20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp20.Visible = False
        '
        'temp19
        '
        Me.temp19.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp19.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp19.GradientColor2 = System.Drawing.Color.White
        Me.temp19.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp19.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp19.Location = New System.Drawing.Point(192, 396)
        Me.temp19.Name = "temp19"
        Me.temp19.Size = New System.Drawing.Size(113, 22)
        Me.temp19.TabIndex = 160
        Me.temp19.Text = "<None>"
        Me.temp19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp19.Visible = False
        '
        'temp18
        '
        Me.temp18.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp18.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp18.GradientColor2 = System.Drawing.Color.White
        Me.temp18.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp18.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp18.Location = New System.Drawing.Point(192, 374)
        Me.temp18.Name = "temp18"
        Me.temp18.Size = New System.Drawing.Size(113, 22)
        Me.temp18.TabIndex = 159
        Me.temp18.Text = "<None>"
        Me.temp18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp18.Visible = False
        '
        'temp17
        '
        Me.temp17.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp17.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp17.GradientColor2 = System.Drawing.Color.White
        Me.temp17.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp17.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp17.Location = New System.Drawing.Point(192, 352)
        Me.temp17.Name = "temp17"
        Me.temp17.Size = New System.Drawing.Size(113, 22)
        Me.temp17.TabIndex = 158
        Me.temp17.Text = "<None>"
        Me.temp17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp17.Visible = False
        '
        'temp16
        '
        Me.temp16.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp16.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp16.GradientColor2 = System.Drawing.Color.White
        Me.temp16.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp16.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp16.Location = New System.Drawing.Point(192, 330)
        Me.temp16.Name = "temp16"
        Me.temp16.Size = New System.Drawing.Size(113, 22)
        Me.temp16.TabIndex = 157
        Me.temp16.Text = "<None>"
        Me.temp16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp16.Visible = False
        '
        'temp15
        '
        Me.temp15.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp15.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp15.GradientColor2 = System.Drawing.Color.White
        Me.temp15.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp15.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp15.Location = New System.Drawing.Point(192, 308)
        Me.temp15.Name = "temp15"
        Me.temp15.Size = New System.Drawing.Size(113, 22)
        Me.temp15.TabIndex = 156
        Me.temp15.Text = "<None>"
        Me.temp15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp15.Visible = False
        '
        'temp14
        '
        Me.temp14.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp14.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp14.GradientColor2 = System.Drawing.Color.White
        Me.temp14.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp14.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp14.Location = New System.Drawing.Point(192, 286)
        Me.temp14.Name = "temp14"
        Me.temp14.Size = New System.Drawing.Size(113, 22)
        Me.temp14.TabIndex = 155
        Me.temp14.Text = "<None>"
        Me.temp14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp14.Visible = False
        '
        'temp13
        '
        Me.temp13.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp13.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp13.GradientColor2 = System.Drawing.Color.White
        Me.temp13.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp13.Location = New System.Drawing.Point(192, 264)
        Me.temp13.Name = "temp13"
        Me.temp13.Size = New System.Drawing.Size(113, 22)
        Me.temp13.TabIndex = 154
        Me.temp13.Text = "<None>"
        Me.temp13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp13.Visible = False
        '
        'temp12
        '
        Me.temp12.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp12.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp12.GradientColor2 = System.Drawing.Color.White
        Me.temp12.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp12.Location = New System.Drawing.Point(192, 242)
        Me.temp12.Name = "temp12"
        Me.temp12.Size = New System.Drawing.Size(113, 22)
        Me.temp12.TabIndex = 153
        Me.temp12.Text = "<None>"
        Me.temp12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp12.Visible = False
        '
        'temp11
        '
        Me.temp11.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp11.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp11.GradientColor2 = System.Drawing.Color.White
        Me.temp11.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp11.Location = New System.Drawing.Point(192, 220)
        Me.temp11.Name = "temp11"
        Me.temp11.Size = New System.Drawing.Size(113, 22)
        Me.temp11.TabIndex = 152
        Me.temp11.Text = "<None>"
        Me.temp11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp11.Visible = False
        '
        'temp10
        '
        Me.temp10.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp10.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp10.GradientColor2 = System.Drawing.Color.White
        Me.temp10.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp10.Location = New System.Drawing.Point(192, 198)
        Me.temp10.Name = "temp10"
        Me.temp10.Size = New System.Drawing.Size(113, 22)
        Me.temp10.TabIndex = 151
        Me.temp10.Text = "<None>"
        Me.temp10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp10.Visible = False
        '
        'temp9
        '
        Me.temp9.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp9.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp9.GradientColor2 = System.Drawing.Color.White
        Me.temp9.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp9.Location = New System.Drawing.Point(192, 176)
        Me.temp9.Name = "temp9"
        Me.temp9.Size = New System.Drawing.Size(113, 22)
        Me.temp9.TabIndex = 150
        Me.temp9.Text = "<None>"
        Me.temp9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp9.Visible = False
        '
        'temp8
        '
        Me.temp8.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp8.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp8.GradientColor2 = System.Drawing.Color.White
        Me.temp8.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp8.Location = New System.Drawing.Point(192, 154)
        Me.temp8.Name = "temp8"
        Me.temp8.Size = New System.Drawing.Size(113, 22)
        Me.temp8.TabIndex = 149
        Me.temp8.Text = "<None>"
        Me.temp8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp8.Visible = False
        '
        'temp7
        '
        Me.temp7.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp7.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp7.GradientColor2 = System.Drawing.Color.White
        Me.temp7.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp7.Location = New System.Drawing.Point(192, 132)
        Me.temp7.Name = "temp7"
        Me.temp7.Size = New System.Drawing.Size(113, 22)
        Me.temp7.TabIndex = 148
        Me.temp7.Text = "<None>"
        Me.temp7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp7.Visible = False
        '
        'temp6
        '
        Me.temp6.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp6.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp6.GradientColor2 = System.Drawing.Color.White
        Me.temp6.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp6.Location = New System.Drawing.Point(192, 110)
        Me.temp6.Name = "temp6"
        Me.temp6.Size = New System.Drawing.Size(113, 22)
        Me.temp6.TabIndex = 147
        Me.temp6.Text = "<None>"
        Me.temp6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp6.Visible = False
        '
        'temp5
        '
        Me.temp5.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp5.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp5.GradientColor2 = System.Drawing.Color.White
        Me.temp5.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp5.Location = New System.Drawing.Point(192, 88)
        Me.temp5.Name = "temp5"
        Me.temp5.Size = New System.Drawing.Size(113, 22)
        Me.temp5.TabIndex = 146
        Me.temp5.Text = "<None>"
        Me.temp5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp5.Visible = False
        '
        'temp3
        '
        Me.temp3.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp3.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp3.GradientColor2 = System.Drawing.Color.White
        Me.temp3.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp3.Location = New System.Drawing.Point(192, 44)
        Me.temp3.Name = "temp3"
        Me.temp3.Size = New System.Drawing.Size(113, 22)
        Me.temp3.TabIndex = 144
        Me.temp3.Text = "<None>"
        Me.temp3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp3.Visible = False
        '
        'temp4
        '
        Me.temp4.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp4.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp4.GradientColor2 = System.Drawing.Color.White
        Me.temp4.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp4.Location = New System.Drawing.Point(192, 66)
        Me.temp4.Name = "temp4"
        Me.temp4.Size = New System.Drawing.Size(113, 22)
        Me.temp4.TabIndex = 145
        Me.temp4.Text = "<None>"
        Me.temp4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp4.Visible = False
        '
        'temp2
        '
        Me.temp2.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp2.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp2.GradientColor2 = System.Drawing.Color.White
        Me.temp2.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp2.Location = New System.Drawing.Point(192, 22)
        Me.temp2.Name = "temp2"
        Me.temp2.Size = New System.Drawing.Size(113, 22)
        Me.temp2.TabIndex = 143
        Me.temp2.Text = "<None>"
        Me.temp2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp2.Visible = False
        '
        'temp1
        '
        Me.temp1.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.temp1.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.temp1.GradientColor2 = System.Drawing.Color.White
        Me.temp1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.temp1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.temp1.Location = New System.Drawing.Point(192, 0)
        Me.temp1.Name = "temp1"
        Me.temp1.Size = New System.Drawing.Size(113, 22)
        Me.temp1.TabIndex = 142
        Me.temp1.Text = "<None>"
        Me.temp1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.temp1.Visible = False
        '
        'clock24
        '
        Me.clock24.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock24.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock24.GradientColor2 = System.Drawing.Color.White
        Me.clock24.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock24.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock24.Location = New System.Drawing.Point(79, 506)
        Me.clock24.Name = "clock24"
        Me.clock24.Size = New System.Drawing.Size(113, 22)
        Me.clock24.TabIndex = 141
        Me.clock24.Text = "<None>"
        Me.clock24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock24.Visible = False
        '
        'clock23
        '
        Me.clock23.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock23.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock23.GradientColor2 = System.Drawing.Color.White
        Me.clock23.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock23.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock23.Location = New System.Drawing.Point(79, 484)
        Me.clock23.Name = "clock23"
        Me.clock23.Size = New System.Drawing.Size(113, 22)
        Me.clock23.TabIndex = 140
        Me.clock23.Text = "<None>"
        Me.clock23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock23.Visible = False
        '
        'clock22
        '
        Me.clock22.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock22.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock22.GradientColor2 = System.Drawing.Color.White
        Me.clock22.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock22.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock22.Location = New System.Drawing.Point(79, 462)
        Me.clock22.Name = "clock22"
        Me.clock22.Size = New System.Drawing.Size(113, 22)
        Me.clock22.TabIndex = 139
        Me.clock22.Text = "<None>"
        Me.clock22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock22.Visible = False
        '
        'clock21
        '
        Me.clock21.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock21.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock21.GradientColor2 = System.Drawing.Color.White
        Me.clock21.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock21.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock21.Location = New System.Drawing.Point(79, 440)
        Me.clock21.Name = "clock21"
        Me.clock21.Size = New System.Drawing.Size(113, 22)
        Me.clock21.TabIndex = 138
        Me.clock21.Text = "<None>"
        Me.clock21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock21.Visible = False
        '
        'clock20
        '
        Me.clock20.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock20.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock20.GradientColor2 = System.Drawing.Color.White
        Me.clock20.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock20.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock20.Location = New System.Drawing.Point(79, 418)
        Me.clock20.Name = "clock20"
        Me.clock20.Size = New System.Drawing.Size(113, 22)
        Me.clock20.TabIndex = 137
        Me.clock20.Text = "<None>"
        Me.clock20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock20.Visible = False
        '
        'clock19
        '
        Me.clock19.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock19.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock19.GradientColor2 = System.Drawing.Color.White
        Me.clock19.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock19.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock19.Location = New System.Drawing.Point(79, 396)
        Me.clock19.Name = "clock19"
        Me.clock19.Size = New System.Drawing.Size(113, 22)
        Me.clock19.TabIndex = 136
        Me.clock19.Text = "<None>"
        Me.clock19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock19.Visible = False
        '
        'clock18
        '
        Me.clock18.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock18.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock18.GradientColor2 = System.Drawing.Color.White
        Me.clock18.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock18.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock18.Location = New System.Drawing.Point(79, 374)
        Me.clock18.Name = "clock18"
        Me.clock18.Size = New System.Drawing.Size(113, 22)
        Me.clock18.TabIndex = 135
        Me.clock18.Text = "<None>"
        Me.clock18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock18.Visible = False
        '
        'clock17
        '
        Me.clock17.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock17.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock17.GradientColor2 = System.Drawing.Color.White
        Me.clock17.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock17.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock17.Location = New System.Drawing.Point(79, 352)
        Me.clock17.Name = "clock17"
        Me.clock17.Size = New System.Drawing.Size(113, 22)
        Me.clock17.TabIndex = 134
        Me.clock17.Text = "<None>"
        Me.clock17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock17.Visible = False
        '
        'clock16
        '
        Me.clock16.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock16.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock16.GradientColor2 = System.Drawing.Color.White
        Me.clock16.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock16.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock16.Location = New System.Drawing.Point(79, 330)
        Me.clock16.Name = "clock16"
        Me.clock16.Size = New System.Drawing.Size(113, 22)
        Me.clock16.TabIndex = 133
        Me.clock16.Text = "<None>"
        Me.clock16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock16.Visible = False
        '
        'clock15
        '
        Me.clock15.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock15.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock15.GradientColor2 = System.Drawing.Color.White
        Me.clock15.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock15.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock15.Location = New System.Drawing.Point(79, 308)
        Me.clock15.Name = "clock15"
        Me.clock15.Size = New System.Drawing.Size(113, 22)
        Me.clock15.TabIndex = 132
        Me.clock15.Text = "<None>"
        Me.clock15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock15.Visible = False
        '
        'clock14
        '
        Me.clock14.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock14.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock14.GradientColor2 = System.Drawing.Color.White
        Me.clock14.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock14.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock14.Location = New System.Drawing.Point(79, 286)
        Me.clock14.Name = "clock14"
        Me.clock14.Size = New System.Drawing.Size(113, 22)
        Me.clock14.TabIndex = 131
        Me.clock14.Text = "<None>"
        Me.clock14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock14.Visible = False
        '
        'clock13
        '
        Me.clock13.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock13.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock13.GradientColor2 = System.Drawing.Color.White
        Me.clock13.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock13.Location = New System.Drawing.Point(79, 264)
        Me.clock13.Name = "clock13"
        Me.clock13.Size = New System.Drawing.Size(113, 22)
        Me.clock13.TabIndex = 130
        Me.clock13.Text = "<None>"
        Me.clock13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock13.Visible = False
        '
        'clock12
        '
        Me.clock12.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock12.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock12.GradientColor2 = System.Drawing.Color.White
        Me.clock12.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock12.Location = New System.Drawing.Point(79, 242)
        Me.clock12.Name = "clock12"
        Me.clock12.Size = New System.Drawing.Size(113, 22)
        Me.clock12.TabIndex = 129
        Me.clock12.Text = "<None>"
        Me.clock12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock12.Visible = False
        '
        'clock11
        '
        Me.clock11.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock11.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock11.GradientColor2 = System.Drawing.Color.White
        Me.clock11.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock11.Location = New System.Drawing.Point(79, 220)
        Me.clock11.Name = "clock11"
        Me.clock11.Size = New System.Drawing.Size(113, 22)
        Me.clock11.TabIndex = 128
        Me.clock11.Text = "<None>"
        Me.clock11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock11.Visible = False
        '
        'clock10
        '
        Me.clock10.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock10.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock10.GradientColor2 = System.Drawing.Color.White
        Me.clock10.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock10.Location = New System.Drawing.Point(79, 198)
        Me.clock10.Name = "clock10"
        Me.clock10.Size = New System.Drawing.Size(113, 22)
        Me.clock10.TabIndex = 127
        Me.clock10.Text = "<None>"
        Me.clock10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock10.Visible = False
        '
        'clock9
        '
        Me.clock9.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock9.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock9.GradientColor2 = System.Drawing.Color.White
        Me.clock9.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock9.Location = New System.Drawing.Point(79, 176)
        Me.clock9.Name = "clock9"
        Me.clock9.Size = New System.Drawing.Size(113, 22)
        Me.clock9.TabIndex = 126
        Me.clock9.Text = "<None>"
        Me.clock9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock9.Visible = False
        '
        'clock8
        '
        Me.clock8.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock8.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock8.GradientColor2 = System.Drawing.Color.White
        Me.clock8.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock8.Location = New System.Drawing.Point(79, 154)
        Me.clock8.Name = "clock8"
        Me.clock8.Size = New System.Drawing.Size(113, 22)
        Me.clock8.TabIndex = 125
        Me.clock8.Text = "<None>"
        Me.clock8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock8.Visible = False
        '
        'clock7
        '
        Me.clock7.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock7.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock7.GradientColor2 = System.Drawing.Color.White
        Me.clock7.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock7.Location = New System.Drawing.Point(79, 132)
        Me.clock7.Name = "clock7"
        Me.clock7.Size = New System.Drawing.Size(113, 22)
        Me.clock7.TabIndex = 124
        Me.clock7.Text = "<None>"
        Me.clock7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock7.Visible = False
        '
        'clock6
        '
        Me.clock6.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock6.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock6.GradientColor2 = System.Drawing.Color.White
        Me.clock6.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock6.Location = New System.Drawing.Point(79, 110)
        Me.clock6.Name = "clock6"
        Me.clock6.Size = New System.Drawing.Size(113, 22)
        Me.clock6.TabIndex = 123
        Me.clock6.Text = "<None>"
        Me.clock6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock6.Visible = False
        '
        'clock5
        '
        Me.clock5.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock5.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock5.GradientColor2 = System.Drawing.Color.White
        Me.clock5.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock5.Location = New System.Drawing.Point(79, 88)
        Me.clock5.Name = "clock5"
        Me.clock5.Size = New System.Drawing.Size(113, 22)
        Me.clock5.TabIndex = 122
        Me.clock5.Text = "<None>"
        Me.clock5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock5.Visible = False
        '
        'clock4
        '
        Me.clock4.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock4.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock4.GradientColor2 = System.Drawing.Color.White
        Me.clock4.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock4.Location = New System.Drawing.Point(79, 66)
        Me.clock4.Name = "clock4"
        Me.clock4.Size = New System.Drawing.Size(113, 22)
        Me.clock4.TabIndex = 121
        Me.clock4.Text = "<None>"
        Me.clock4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock4.Visible = False
        '
        'clock3
        '
        Me.clock3.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock3.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock3.GradientColor2 = System.Drawing.Color.White
        Me.clock3.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock3.Location = New System.Drawing.Point(79, 44)
        Me.clock3.Name = "clock3"
        Me.clock3.Size = New System.Drawing.Size(113, 22)
        Me.clock3.TabIndex = 120
        Me.clock3.Text = "<None>"
        Me.clock3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock3.Visible = False
        '
        'clock2
        '
        Me.clock2.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock2.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock2.GradientColor2 = System.Drawing.Color.White
        Me.clock2.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock2.Location = New System.Drawing.Point(79, 22)
        Me.clock2.Name = "clock2"
        Me.clock2.Size = New System.Drawing.Size(113, 22)
        Me.clock2.TabIndex = 119
        Me.clock2.Text = "<None>"
        Me.clock2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock2.Visible = False
        '
        'clock1
        '
        Me.clock1.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.clock1.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.clock1.GradientColor2 = System.Drawing.Color.White
        Me.clock1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.clock1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clock1.Location = New System.Drawing.Point(79, 0)
        Me.clock1.Name = "clock1"
        Me.clock1.Size = New System.Drawing.Size(113, 22)
        Me.clock1.TabIndex = 118
        Me.clock1.Text = "<None>"
        Me.clock1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.clock1.Visible = False
        '
        'core24
        '
        Me.core24.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core24.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core24.GradientColor2 = System.Drawing.Color.White
        Me.core24.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core24.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core24.Location = New System.Drawing.Point(0, 506)
        Me.core24.Name = "core24"
        Me.core24.Size = New System.Drawing.Size(79, 22)
        Me.core24.TabIndex = 117
        Me.core24.Text = "Core #24"
        Me.core24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core24.Visible = False
        '
        'core23
        '
        Me.core23.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core23.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core23.GradientColor2 = System.Drawing.Color.White
        Me.core23.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core23.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core23.Location = New System.Drawing.Point(0, 484)
        Me.core23.Name = "core23"
        Me.core23.Size = New System.Drawing.Size(79, 22)
        Me.core23.TabIndex = 116
        Me.core23.Text = "Core #23"
        Me.core23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core23.Visible = False
        '
        'core22
        '
        Me.core22.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core22.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core22.GradientColor2 = System.Drawing.Color.White
        Me.core22.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core22.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core22.Location = New System.Drawing.Point(0, 462)
        Me.core22.Name = "core22"
        Me.core22.Size = New System.Drawing.Size(79, 22)
        Me.core22.TabIndex = 115
        Me.core22.Text = "Core #22"
        Me.core22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core22.Visible = False
        '
        'core21
        '
        Me.core21.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core21.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core21.GradientColor2 = System.Drawing.Color.White
        Me.core21.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core21.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core21.Location = New System.Drawing.Point(0, 440)
        Me.core21.Name = "core21"
        Me.core21.Size = New System.Drawing.Size(79, 22)
        Me.core21.TabIndex = 114
        Me.core21.Text = "Core #21"
        Me.core21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core21.Visible = False
        '
        'core20
        '
        Me.core20.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core20.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core20.GradientColor2 = System.Drawing.Color.White
        Me.core20.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core20.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core20.Location = New System.Drawing.Point(0, 418)
        Me.core20.Name = "core20"
        Me.core20.Size = New System.Drawing.Size(79, 22)
        Me.core20.TabIndex = 113
        Me.core20.Text = "Core #20"
        Me.core20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core20.Visible = False
        '
        'core19
        '
        Me.core19.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core19.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core19.GradientColor2 = System.Drawing.Color.White
        Me.core19.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core19.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core19.Location = New System.Drawing.Point(0, 396)
        Me.core19.Name = "core19"
        Me.core19.Size = New System.Drawing.Size(79, 22)
        Me.core19.TabIndex = 112
        Me.core19.Text = "Core #19"
        Me.core19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core19.Visible = False
        '
        'core18
        '
        Me.core18.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core18.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core18.GradientColor2 = System.Drawing.Color.White
        Me.core18.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core18.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core18.Location = New System.Drawing.Point(0, 374)
        Me.core18.Name = "core18"
        Me.core18.Size = New System.Drawing.Size(79, 22)
        Me.core18.TabIndex = 111
        Me.core18.Text = "Core #18"
        Me.core18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core18.Visible = False
        '
        'core17
        '
        Me.core17.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core17.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core17.GradientColor2 = System.Drawing.Color.White
        Me.core17.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core17.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core17.Location = New System.Drawing.Point(0, 352)
        Me.core17.Name = "core17"
        Me.core17.Size = New System.Drawing.Size(79, 22)
        Me.core17.TabIndex = 110
        Me.core17.Text = "Core #17"
        Me.core17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core17.Visible = False
        '
        'core16
        '
        Me.core16.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core16.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core16.GradientColor2 = System.Drawing.Color.White
        Me.core16.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core16.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core16.Location = New System.Drawing.Point(0, 330)
        Me.core16.Name = "core16"
        Me.core16.Size = New System.Drawing.Size(79, 22)
        Me.core16.TabIndex = 109
        Me.core16.Text = "Core #16"
        Me.core16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core16.Visible = False
        '
        'core15
        '
        Me.core15.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core15.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core15.GradientColor2 = System.Drawing.Color.White
        Me.core15.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core15.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core15.Location = New System.Drawing.Point(0, 308)
        Me.core15.Name = "core15"
        Me.core15.Size = New System.Drawing.Size(79, 22)
        Me.core15.TabIndex = 108
        Me.core15.Text = "Core #15"
        Me.core15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core15.Visible = False
        '
        'core14
        '
        Me.core14.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core14.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core14.GradientColor2 = System.Drawing.Color.White
        Me.core14.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core14.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core14.Location = New System.Drawing.Point(0, 286)
        Me.core14.Name = "core14"
        Me.core14.Size = New System.Drawing.Size(79, 22)
        Me.core14.TabIndex = 107
        Me.core14.Text = "Core #14"
        Me.core14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core14.Visible = False
        '
        'core13
        '
        Me.core13.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core13.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core13.GradientColor2 = System.Drawing.Color.White
        Me.core13.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core13.Location = New System.Drawing.Point(0, 264)
        Me.core13.Name = "core13"
        Me.core13.Size = New System.Drawing.Size(79, 22)
        Me.core13.TabIndex = 106
        Me.core13.Text = "Core #13"
        Me.core13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core13.Visible = False
        '
        'core12
        '
        Me.core12.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core12.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core12.GradientColor2 = System.Drawing.Color.White
        Me.core12.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core12.Location = New System.Drawing.Point(0, 242)
        Me.core12.Name = "core12"
        Me.core12.Size = New System.Drawing.Size(79, 22)
        Me.core12.TabIndex = 105
        Me.core12.Text = "Core #12"
        Me.core12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core12.Visible = False
        '
        'core11
        '
        Me.core11.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core11.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core11.GradientColor2 = System.Drawing.Color.White
        Me.core11.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core11.Location = New System.Drawing.Point(0, 220)
        Me.core11.Name = "core11"
        Me.core11.Size = New System.Drawing.Size(79, 22)
        Me.core11.TabIndex = 104
        Me.core11.Text = "Core #11"
        Me.core11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core11.Visible = False
        '
        'core10
        '
        Me.core10.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core10.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core10.GradientColor2 = System.Drawing.Color.White
        Me.core10.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core10.Location = New System.Drawing.Point(0, 198)
        Me.core10.Name = "core10"
        Me.core10.Size = New System.Drawing.Size(79, 22)
        Me.core10.TabIndex = 103
        Me.core10.Text = "Core #10"
        Me.core10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core10.Visible = False
        '
        'core9
        '
        Me.core9.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core9.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core9.GradientColor2 = System.Drawing.Color.White
        Me.core9.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core9.Location = New System.Drawing.Point(0, 176)
        Me.core9.Name = "core9"
        Me.core9.Size = New System.Drawing.Size(79, 22)
        Me.core9.TabIndex = 102
        Me.core9.Text = "Core #9"
        Me.core9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core9.Visible = False
        '
        'core8
        '
        Me.core8.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core8.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core8.GradientColor2 = System.Drawing.Color.White
        Me.core8.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core8.Location = New System.Drawing.Point(0, 154)
        Me.core8.Name = "core8"
        Me.core8.Size = New System.Drawing.Size(79, 22)
        Me.core8.TabIndex = 101
        Me.core8.Text = "Core #8"
        Me.core8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core8.Visible = False
        '
        'core7
        '
        Me.core7.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core7.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core7.GradientColor2 = System.Drawing.Color.White
        Me.core7.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core7.Location = New System.Drawing.Point(0, 132)
        Me.core7.Name = "core7"
        Me.core7.Size = New System.Drawing.Size(79, 22)
        Me.core7.TabIndex = 100
        Me.core7.Text = "Core #7"
        Me.core7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core7.Visible = False
        '
        'core6
        '
        Me.core6.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core6.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core6.GradientColor2 = System.Drawing.Color.White
        Me.core6.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core6.Location = New System.Drawing.Point(0, 110)
        Me.core6.Name = "core6"
        Me.core6.Size = New System.Drawing.Size(79, 22)
        Me.core6.TabIndex = 99
        Me.core6.Text = "Core #6"
        Me.core6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core6.Visible = False
        '
        'core5
        '
        Me.core5.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core5.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core5.GradientColor2 = System.Drawing.Color.White
        Me.core5.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core5.Location = New System.Drawing.Point(0, 88)
        Me.core5.Name = "core5"
        Me.core5.Size = New System.Drawing.Size(79, 22)
        Me.core5.TabIndex = 98
        Me.core5.Text = "Core #5"
        Me.core5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core5.Visible = False
        '
        'core4
        '
        Me.core4.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core4.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core4.GradientColor2 = System.Drawing.Color.White
        Me.core4.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core4.Location = New System.Drawing.Point(0, 66)
        Me.core4.Name = "core4"
        Me.core4.Size = New System.Drawing.Size(79, 22)
        Me.core4.TabIndex = 97
        Me.core4.Text = "Core #4"
        Me.core4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core4.Visible = False
        '
        'core3
        '
        Me.core3.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core3.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core3.GradientColor2 = System.Drawing.Color.White
        Me.core3.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core3.Location = New System.Drawing.Point(0, 44)
        Me.core3.Name = "core3"
        Me.core3.Size = New System.Drawing.Size(79, 22)
        Me.core3.TabIndex = 96
        Me.core3.Text = "Core #3"
        Me.core3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core3.Visible = False
        '
        'core2
        '
        Me.core2.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core2.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core2.GradientColor2 = System.Drawing.Color.White
        Me.core2.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core2.Location = New System.Drawing.Point(0, 22)
        Me.core2.Name = "core2"
        Me.core2.Size = New System.Drawing.Size(79, 22)
        Me.core2.TabIndex = 95
        Me.core2.Text = "Core #2"
        Me.core2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core2.Visible = False
        '
        'core1
        '
        Me.core1.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.core1.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.core1.GradientColor2 = System.Drawing.Color.White
        Me.core1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.core1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.core1.Location = New System.Drawing.Point(0, 0)
        Me.core1.Name = "core1"
        Me.core1.Size = New System.Drawing.Size(79, 22)
        Me.core1.TabIndex = 84
        Me.core1.Text = "Core #1"
        Me.core1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.core1.Visible = False
        '
        'GradientLabel4
        '
        Me.GradientLabel4.ForeColor = System.Drawing.Color.Olive
        Me.GradientLabel4.GradientColor1 = System.Drawing.Color.White
        Me.GradientLabel4.GradientColor2 = System.Drawing.SystemColors.ButtonHighlight
        Me.GradientLabel4.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.GradientLabel4.Location = New System.Drawing.Point(92, 152)
        Me.GradientLabel4.Name = "GradientLabel4"
        Me.GradientLabel4.Size = New System.Drawing.Size(110, 40)
        Me.GradientLabel4.TabIndex = 91
        Me.GradientLabel4.Text = "#Core Voltage"
        Me.GradientLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'GradientLabel5
        '
        Me.GradientLabel5.ForeColor = System.Drawing.Color.Maroon
        Me.GradientLabel5.GradientColor1 = System.Drawing.Color.White
        Me.GradientLabel5.GradientColor2 = System.Drawing.SystemColors.ButtonHighlight
        Me.GradientLabel5.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.GradientLabel5.Location = New System.Drawing.Point(202, 152)
        Me.GradientLabel5.Name = "GradientLabel5"
        Me.GradientLabel5.Size = New System.Drawing.Size(113, 40)
        Me.GradientLabel5.TabIndex = 92
        Me.GradientLabel5.Text = "#Core Temp"
        Me.GradientLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(343, 389)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.GradientLabel3)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblCpuName)
        Me.Controls.Add(Me.GradientLabel2)
        Me.Controls.Add(Me.GradientLabel1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.CheckBox3)
        Me.Controls.Add(Me.CheckBox4)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.GradientLabel4)
        Me.Controls.Add(Me.GradientLabel5)
        Me.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel1.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents refreshTimer As System.Windows.Forms.Timer
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblRPM As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveReportTXTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveGraphPNGToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GraphThemesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SlateGrayToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TealDefaultToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DarkBlueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MidnightPurpleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmeraldGreenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FireOrangeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OceanBlueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SteelGrayToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SunsetPinkToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GoldBrownToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CyanTealToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SilverToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ShowUnlistedCoreToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StayOnTopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TimerUI As System.Windows.Forms.Timer
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents EnterSerialKeyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents core1 As HeatMon.GradientLabel
    Friend WithEvents core24 As HeatMon.GradientLabel
    Friend WithEvents core23 As HeatMon.GradientLabel
    Friend WithEvents core22 As HeatMon.GradientLabel
    Friend WithEvents core21 As HeatMon.GradientLabel
    Friend WithEvents core20 As HeatMon.GradientLabel
    Friend WithEvents core19 As HeatMon.GradientLabel
    Friend WithEvents core18 As HeatMon.GradientLabel
    Friend WithEvents core17 As HeatMon.GradientLabel
    Friend WithEvents core16 As HeatMon.GradientLabel
    Friend WithEvents core15 As HeatMon.GradientLabel
    Friend WithEvents core14 As HeatMon.GradientLabel
    Friend WithEvents core13 As HeatMon.GradientLabel
    Friend WithEvents core12 As HeatMon.GradientLabel
    Friend WithEvents core11 As HeatMon.GradientLabel
    Friend WithEvents core10 As HeatMon.GradientLabel
    Friend WithEvents core9 As HeatMon.GradientLabel
    Friend WithEvents core8 As HeatMon.GradientLabel
    Friend WithEvents core7 As HeatMon.GradientLabel
    Friend WithEvents core6 As HeatMon.GradientLabel
    Friend WithEvents core5 As HeatMon.GradientLabel
    Friend WithEvents core4 As HeatMon.GradientLabel
    Friend WithEvents core3 As HeatMon.GradientLabel
    Friend WithEvents core2 As HeatMon.GradientLabel
    Friend WithEvents clock24 As HeatMon.GradientLabel
    Friend WithEvents clock23 As HeatMon.GradientLabel
    Friend WithEvents clock22 As HeatMon.GradientLabel
    Friend WithEvents clock21 As HeatMon.GradientLabel
    Friend WithEvents clock20 As HeatMon.GradientLabel
    Friend WithEvents clock19 As HeatMon.GradientLabel
    Friend WithEvents clock18 As HeatMon.GradientLabel
    Friend WithEvents clock17 As HeatMon.GradientLabel
    Friend WithEvents clock16 As HeatMon.GradientLabel
    Friend WithEvents clock15 As HeatMon.GradientLabel
    Friend WithEvents clock14 As HeatMon.GradientLabel
    Friend WithEvents clock13 As HeatMon.GradientLabel
    Friend WithEvents clock12 As HeatMon.GradientLabel
    Friend WithEvents clock11 As HeatMon.GradientLabel
    Friend WithEvents clock10 As HeatMon.GradientLabel
    Friend WithEvents clock9 As HeatMon.GradientLabel
    Friend WithEvents clock8 As HeatMon.GradientLabel
    Friend WithEvents clock7 As HeatMon.GradientLabel
    Friend WithEvents clock6 As HeatMon.GradientLabel
    Friend WithEvents clock5 As HeatMon.GradientLabel
    Friend WithEvents clock4 As HeatMon.GradientLabel
    Friend WithEvents clock3 As HeatMon.GradientLabel
    Friend WithEvents clock2 As HeatMon.GradientLabel
    Friend WithEvents clock1 As HeatMon.GradientLabel
    Friend WithEvents temp24 As HeatMon.GradientLabel
    Friend WithEvents temp23 As HeatMon.GradientLabel
    Friend WithEvents temp22 As HeatMon.GradientLabel
    Friend WithEvents temp21 As HeatMon.GradientLabel
    Friend WithEvents temp20 As HeatMon.GradientLabel
    Friend WithEvents temp19 As HeatMon.GradientLabel
    Friend WithEvents temp18 As HeatMon.GradientLabel
    Friend WithEvents temp17 As HeatMon.GradientLabel
    Friend WithEvents temp16 As HeatMon.GradientLabel
    Friend WithEvents temp15 As HeatMon.GradientLabel
    Friend WithEvents temp14 As HeatMon.GradientLabel
    Friend WithEvents temp13 As HeatMon.GradientLabel
    Friend WithEvents temp12 As HeatMon.GradientLabel
    Friend WithEvents temp11 As HeatMon.GradientLabel
    Friend WithEvents temp10 As HeatMon.GradientLabel
    Friend WithEvents temp9 As HeatMon.GradientLabel
    Friend WithEvents temp8 As HeatMon.GradientLabel
    Friend WithEvents temp7 As HeatMon.GradientLabel
    Friend WithEvents temp6 As HeatMon.GradientLabel
    Friend WithEvents temp5 As HeatMon.GradientLabel
    Friend WithEvents temp4 As HeatMon.GradientLabel
    Friend WithEvents temp3 As HeatMon.GradientLabel
    Friend WithEvents temp2 As HeatMon.GradientLabel
    Friend WithEvents temp1 As HeatMon.GradientLabel
    Friend WithEvents Label4 As HeatMon.GradientLabel
    Friend WithEvents Label5 As HeatMon.GradientLabel
    Friend WithEvents GradientLabel1 As HeatMon.GradientLabel
    Friend WithEvents GradientLabel2 As HeatMon.GradientLabel
    Friend WithEvents lblCpuName As HeatMon.GradientLabel
    Friend WithEvents Label3 As HeatMon.GradientLabel
    Friend WithEvents GradientLabel3 As HeatMon.GradientLabel
    Friend WithEvents GradientLabel4 As HeatMon.GradientLabel
    Friend WithEvents GradientLabel5 As HeatMon.GradientLabel
    Friend WithEvents ShowGraphToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel

End Class
