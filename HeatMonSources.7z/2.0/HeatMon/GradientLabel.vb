﻿Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Windows.Forms

Public Class GradientLabel
    Inherits Label

    Public Property GradientColor1 As Color = Color.DarkBlue
    Public Property GradientColor2 As Color = Color.MediumBlue
    Public Property GradientMode As LinearGradientMode = LinearGradientMode.Vertical

    Protected Overrides Sub OnPaint(e As PaintEventArgs)
        ' Gambar gradient background
        Using brush As New LinearGradientBrush(Me.ClientRectangle, GradientColor1, GradientColor2, GradientMode)
            e.Graphics.FillRectangle(brush, Me.ClientRectangle)
        End Using

        ' Gambar text dan image seperti biasa
        MyBase.OnPaint(e)
    End Sub
End Class
