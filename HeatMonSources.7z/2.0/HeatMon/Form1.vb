﻿Imports HeatMonLib
Imports System.Threading
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Collections.Generic
Imports System.Reflection
Imports System.IO

Public Class Form1
    Private reader As HeatMonLib.HeatMonLib
    Private monitorThread As Thread
    Private running As Boolean = True
    Private formLoaded As Boolean = False
    Private isFahrenheit As Boolean = False
    Private isGHz As Boolean = False
    Private showCoolingRPM As Boolean = False
    Private clockcolor As Color
    Private tempcolor As Color
    Private clockLabels As List(Of GradientLabel)
    Public tempLabels As List(Of GradientLabel)
    Private coreclocklabels As List(Of GradientLabel)
    Private tempHistory As New ArrayList()
    Private clockHistory As New ArrayList()
    Private maxHistory As Integer = 60

    ' Variables for thread-safe UI update
    Private cpuNameForUI As String
    Private clocksForUI As List(Of Single)
    Private tempsForUI As List(Of Single)
    Private coreCountForUI As Integer

    ' Variabel untuk smoothing cooling percentage
    Private smoothedCoolingPercents(7) As Single
    Private isedit As Boolean = True
    ' Tambah di atas class Form1
    Private startTime As DateTime = DateTime.Now

    ' 🔹 Handler umum untuk semua item tema
    Private Sub ThemeMenuItem_Click(sender As Object, e As EventArgs) _
        Handles TealDefaultToolStripMenuItem.Click, SlateGrayToolStripMenuItem.Click, DarkBlueToolStripMenuItem.Click, _
                MidnightPurpleToolStripMenuItem.Click, EmeraldGreenToolStripMenuItem.Click, FireOrangeToolStripMenuItem.Click, _
                OceanBlueToolStripMenuItem.Click, SteelGrayToolStripMenuItem.Click, SunsetPinkToolStripMenuItem.Click, _
                GoldBrownToolStripMenuItem.Click, CyanTealToolStripMenuItem.Click, SilverToolStripMenuItem.Click

        ' Loop semua item di dalam ThemeToolStripMenuItem
        For Each item As ToolStripMenuItem In GraphThemesToolStripMenuItem.DropDownItems
            item.Checked = False
        Next

        ' Aktifkan item yang diklik
        Dim clickedItem As ToolStripMenuItem = CType(sender, ToolStripMenuItem)
        clickedItem.Checked = True

        ' Refresh tampilan setelah ganti tema
        PictureBox1.Invalidate()
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Try
            running = False
            If reader IsNot Nothing Then
                Try
                    reader.Close()
                Catch
                End Try
                reader = Nothing
            End If
            If monitorThread IsNot Nothing AndAlso monitorThread.IsAlive Then
                monitorThread.Join(500)
            End If
        Catch
        Finally
            Environment.Exit(0)
        End Try
    End Sub

    Private Function CoolingPercentToRPM(percent As Single) As Single
        Dim maxRPM As Single = 3000.0F
        Return (percent / 100.0F) * maxRPM
    End Function
    Sub cekifreg()
        Dim fileName As String = "reg"

        ' Path folder program (folder exe)
        Dim programFolder As String = AppDomain.CurrentDomain.BaseDirectory
        Dim fullPath As String = Path.Combine(programFolder, fileName)

        ' Cek apakah file ada
        If File.Exists(fullPath) Then
            'Console.WriteLine("File sudah ada di folder program: " & fullPath)
            Me.Text = "HeatMon - Commercial use"
        Else
            Me.Text = "HeatMon - Personal use only"
        End If

        Console.ReadLine()
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Icon = My.Resources.favicon1
        cekifreg()
        reader = New HeatMonLib.HeatMonLib("ari", "D2EFAA6DD6AE6136C199")
        formLoaded = True

        Me.Width = 349
        Me.Height = 418
        ' Initialize labels
        For Each item As ToolStripMenuItem In GraphThemesToolStripMenuItem.DropDownItems
            AddHandler item.Click, AddressOf ThemeMenuItem_Click
        Next
        clockLabels = New List(Of GradientLabel)({clock1, clock2, clock3, clock4, clock5, clock6, clock7, clock8, clock9, clock10, clock11, clock12, clock13, clock14, clock15, clock16, clock17, clock18, clock19, clock20, clock21, clock22, clock23, clock24})
        tempLabels = New List(Of GradientLabel)({temp1, temp2, temp3, temp4, temp5, temp6, temp7, temp8, temp9, temp10, temp11, temp12, temp13, temp14, temp15, temp16, temp17, temp18, temp19, temp20, temp21, temp22, temp23, temp24})
        coreclocklabels = New List(Of GradientLabel)({core1, core2, core3, core4, core5, core6, core7, core8, core9, core10, core11, core12, core13, core14, core15, core16, core17, core18, core19, core20, core21, core22, core23, core24})
        ' Init history
        For i As Integer = 0 To 7
            tempHistory.Add(New ArrayList())
            clockHistory.Add(New ArrayList())
            smoothedCoolingPercents(i) = 0
        Next
        Label4.Text = Environment.MachineName
        Label5.Text = Environment.UserName
        clockcolor = Color.Orange
        tempcolor = Color.LightCoral
        TimerUI.Interval = 1000 ' update tiap 1 detik
        TimerUI.Start()
        ' Start monitoring
        monitorThread = New Thread(AddressOf MonitorLoop)
        monitorThread.IsBackground = True
        monitorThread.Start()


    End Sub
    Private Function CalculateFanRPM(tempC As Single) As Integer
        ' RPM minimum dan maksimum
        Dim minTemp As Single = 30
        Dim maxTemp As Single = 90
        Dim minRPM As Integer = 1000
        Dim maxRPM As Integer = 5000

        If tempC <= minTemp Then
            Return minRPM
        ElseIf tempC >= maxTemp Then
            Return maxRPM
        Else
            ' interpolasi linear
            Dim ratio As Single = (tempC - minTemp) / (maxTemp - minTemp)
            Return CInt(minRPM + ratio * (maxRPM - minRPM))
        End If
    End Function
    Private Sub MonitorLoop()
        While running
            Try
                reader.UpdateAll()
                Dim cpuName As String = reader.GetCpuName()
                Dim clocks As List(Of Single) = reader.GetCpuClocks()
                Dim temps As List(Of Single) = reader.GetCpuTemps()
                Dim coreCount As Integer = clocks.Count

                ' Update history
                For i As Integer = 0 To coreCount - 1
                    CType(clockHistory(i), ArrayList).Add(clocks(i))
                    If CType(clockHistory(i), ArrayList).Count > maxHistory Then
                        CType(clockHistory(i), ArrayList).RemoveAt(0)
                    End If
                    CType(tempHistory(i), ArrayList).Add(temps(i))
                    If CType(tempHistory(i), ArrayList).Count > maxHistory Then
                        CType(tempHistory(i), ArrayList).RemoveAt(0)
                    End If
                Next

                cpuNameForUI = cpuName
                clocksForUI = clocks
                tempsForUI = temps
                coreCountForUI = coreCount

                If Me.IsHandleCreated Then
                    Me.Invoke(New MethodInvoker(AddressOf UpdateUI))
                End If

            Catch ex As Exception
            End Try
            Thread.Sleep(1000)
        End While
    End Sub
    Sub coremeans()
        Select Case coreCountForUI
            Case 1
                Label3.Text = "Single-Core CPU"
            Case 2
                Label3.Text = "Dual-Core CPU"
            Case 3
                Label3.Text = "Triple-Core CPU"
            Case 4
                Label3.Text = "Quad-Core CPU"
            Case 5
                Label3.Text = "Penta-Core CPU"
            Case 6
                Label3.Text = "Hexa-Core CPU"
            Case 7
                Label3.Text = "Hepta-Core CPU"
            Case 8
                Label3.Text = "Octa-Core CPU"
            Case 9
                Label3.Text = "Nona-Core CPU"
            Case 10
                Label3.Text = "Deca-Core CPU"
            Case 11
                Label3.Text = "Undeca-Core CPU"
            Case 12
                Label3.Text = "Dodeca-Core CPU"
            Case 13
                Label3.Text = "Trideca-Core CPU"
            Case 14
                Label3.Text = "Tetradeca-Core CPU"
            Case 15
                Label3.Text = "Pentadeca-Core CPU"
            Case 16
                Label3.Text = "Hexadeca-Core CPU"
            Case Else
                ' Untuk core lebih dari 16 langsung pakai format angka
                Label3.Text = coreCountForUI.ToString() & "-core CPU"
        End Select
    End Sub
   
    Private Sub UpdateUI()
        ' Update CPU name
        lblCpuName.Text = cpuNameForUI
        coremeans()

        ' 🔹 Ambil data voltase dari HeatMonLib
        Dim volts As List(Of Double)
        If isGHz Then
            ' Mode Volt
            volts = reader.GetCpuVoltages()
        Else
            ' Mode mV
            volts = reader.GetCpuVoltages_mV()
        End If

        ' Update Voltage labels
        For i = 0 To clockLabels.Count - 1
            If i < coreCountForUI Then
                clockLabels(i).Visible = True
                coreclocklabels(i).Visible = True

                Dim displayVal As Double = volts(i)
                Dim unit As String = If(isGHz, "V", "mV")

                clockLabels(i).Text = displayVal.ToString("0.00") & " " & unit
                clockLabels(i).Image = My.Resources.voltage
                clockLabels(i).GradientColor1 = Color.FromArgb(192, 192, 0)
                clockLabels(i).GradientColor2 = Color.Gainsboro
                clockLabels(i).ForeColor = Color.White
                clockLabels(i).Font = New Font(clockLabels(i).Font, FontStyle.Bold)

                coreclocklabels(i).Image = My.Resources.icons8_graph_16
                coreclocklabels(i).GradientColor1 = Color.Blue
                coreclocklabels(i).GradientColor2 = Color.Gainsboro
                coreclocklabels(i).ForeColor = Color.White
                coreclocklabels(i).Font = New Font(coreclocklabels(i).Font, FontStyle.Bold)

            Else
                If ShowUnlistedCoreToolStripMenuItem.Checked Then
                    clockLabels(i).Visible = True
                    clockLabels(i).Enabled = False
                    coreclocklabels(i).Visible = True
                    coreclocklabels(i).Enabled = False
                Else
                    clockLabels(i).Visible = False
                    coreclocklabels(i).Visible = False
                End If
                coreclocklabels(i).Image = Nothing
                clockLabels(i).Image = Nothing
                coreclocklabels(i).Text = "<None>"
            End If
        Next

        ' Update Temp labels
        For i = 0 To tempLabels.Count - 1
            If i < coreCountForUI Then
                tempLabels(i).Visible = True
                Dim displayTemp As Single = tempsForUI(i)
                Dim unit As String = "°C"
                If isFahrenheit Then
                    displayTemp = displayTemp * 9 / 5 + 32
                    unit = "°F"
                End If
                tempLabels(i).Text = displayTemp.ToString("0.0") & " " & unit
                tempLabels(i).Image = My.Resources.temperature
                tempLabels(i).GradientColor1 = Color.FromArgb(192, 0, 0)
                tempLabels(i).GradientColor2 = Color.Gainsboro
                tempLabels(i).ForeColor = Color.White
                tempLabels(i).Font = New Font(tempLabels(i).Font, FontStyle.Bold)
            Else
                If ShowUnlistedCoreToolStripMenuItem.Checked Then
                    tempLabels(i).Visible = True
                    tempLabels(i).Enabled = False
                Else
                    tempLabels(i).Visible = False
                End If

                tempLabels(i).Image = Nothing
            End If
        Next

        If FanChecker.HasFan Then
            ' --- Hitung suhu maksimum dari semua core untuk acuan fan ---
            Dim maxTemp As Single = Single.MinValue
            For core As Integer = 0 To coreCountForUI - 1
                If core < tempHistory.Count Then
                    Dim history As ArrayList = CType(tempHistory(core), ArrayList)
                    If history.Count > 0 Then
                        Dim lastVal As Single = CSng(history(history.Count - 1))
                        If lastVal > maxTemp Then maxTemp = lastVal
                    End If
                End If
            Next

            If maxTemp > Single.MinValue Then
                Dim rpm As Integer = CalculateFanRPM(maxTemp)
                lblRPM.Text = rpm.ToString("N0") & " RPM"
            End If
        Else
            PictureBox2.Enabled = False
            lblRPM.Text = "No Detected"
        End If
        PictureBox1.Invalidate()
    End Sub
    Private Function FindMinValue(ByVal data As List(Of Single)) As Single
        If data.Count = 0 Then Return 0
        Dim minVal As Single = data(0)
        For Each value As Single In data
            If value < minVal Then minVal = value
        Next
        Return minVal
    End Function

    Private Function FindMaxValue(ByVal data As List(Of Single)) As Single
        If data.Count = 0 Then Return 1
        Dim maxVal As Single = data(0)
        For Each value As Single In data
            If value > maxVal Then maxVal = value
        Next
        Return maxVal
    End Function
    ' Checkbox event handlers
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If Not formLoaded Then Exit Sub
        RemoveHandler CheckBox2.CheckedChanged, AddressOf CheckBox2_CheckedChanged
        isGHz = Not CheckBox1.Checked
        CheckBox2.Checked = Not CheckBox1.Checked
        UpdateUI()
        AddHandler CheckBox2.CheckedChanged, AddressOf CheckBox2_CheckedChanged
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If Not formLoaded Then Exit Sub
        RemoveHandler CheckBox1.CheckedChanged, AddressOf CheckBox1_CheckedChanged
        isGHz = CheckBox2.Checked
        CheckBox1.Checked = Not CheckBox2.Checked
        UpdateUI()
        AddHandler CheckBox1.CheckedChanged, AddressOf CheckBox1_CheckedChanged
    End Sub

    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox4.CheckedChanged
        If Not formLoaded Then Exit Sub
        RemoveHandler CheckBox3.CheckedChanged, AddressOf CheckBox3_CheckedChanged
        isFahrenheit = Not CheckBox4.Checked
        CheckBox3.Checked = Not CheckBox4.Checked
        UpdateUI()
        AddHandler CheckBox3.CheckedChanged, AddressOf CheckBox3_CheckedChanged
    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        If Not formLoaded Then Exit Sub
        RemoveHandler CheckBox4.CheckedChanged, AddressOf CheckBox4_CheckedChanged
        isFahrenheit = CheckBox3.Checked
        CheckBox4.Checked = Not CheckBox3.Checked
        UpdateUI()
        AddHandler CheckBox4.CheckedChanged, AddressOf CheckBox4_CheckedChanged
    End Sub

    Private Sub PictureBox1_Paint(sender As Object, e As PaintEventArgs) Handles PictureBox1.Paint
        Dim g As Graphics = e.Graphics
        g.SmoothingMode = SmoothingMode.AntiAlias
        g.Clear(Color.FromArgb(20, 20, 20))

        Dim w As Integer = PictureBox1.Width
        Dim h As Integer = PictureBox1.Height
        Dim rect As New System.Drawing.Rectangle(0, 0, w, h)

        Dim bgBrush As System.Drawing.Drawing2D.LinearGradientBrush = Nothing
        Try
            ' Pilih salah satu kombinasi warna yang profesional (uncomment salah satu)
            ' 1) Dark blue -> near black
            If DarkBlueToolStripMenuItem.Checked Then
                bgBrush = New System.Drawing.Drawing2D.LinearGradientBrush(rect, _
                       System.Drawing.Color.FromArgb(18, 40, 90), System.Drawing.Color.FromArgb(6, 10, 18), _
                       System.Drawing.Drawing2D.LinearGradientMode.Vertical)

            End If
            ' 2) Slate gray -> black
            If SlateGrayToolStripMenuItem.Checked Then
                bgBrush = New System.Drawing.Drawing2D.LinearGradientBrush(rect, _
                      System.Drawing.Color.FromArgb(50, 60, 70), System.Drawing.Color.FromArgb(12, 14, 16), _
                   System.Drawing.Drawing2D.LinearGradientMode.Vertical)

            End If

            ' 3) Teal -> deep (default contoh)
            If TealDefaultToolStripMenuItem.Checked Then
                bgBrush = New System.Drawing.Drawing2D.LinearGradientBrush(rect, _
                        System.Drawing.Color.FromArgb(18, 86, 101), System.Drawing.Color.FromArgb(8, 24, 30), _
                        System.Drawing.Drawing2D.LinearGradientMode.Vertical)
            End If

            ' 4) Midnight Purple -> Deep Black
            If MidnightPurpleToolStripMenuItem.Checked Then
                bgBrush = New System.Drawing.Drawing2D.LinearGradientBrush(rect, _
                       System.Drawing.Color.FromArgb(48, 25, 52), System.Drawing.Color.FromArgb(10, 5, 15), _
                       System.Drawing.Drawing2D.LinearGradientMode.Vertical)
            End If

            ' 5) Emerald Green -> Dark Forest
            If EmeraldGreenToolStripMenuItem.Checked Then
                bgBrush = New System.Drawing.Drawing2D.LinearGradientBrush(rect, _
                       System.Drawing.Color.FromArgb(16, 94, 65), System.Drawing.Color.FromArgb(6, 24, 15), _
                       System.Drawing.Drawing2D.LinearGradientMode.Vertical)
            End If

            ' 6) Fire Orange -> Dark Red
            If FireOrangeToolStripMenuItem.Checked Then
                bgBrush = New System.Drawing.Drawing2D.LinearGradientBrush(rect, _
                       System.Drawing.Color.FromArgb(220, 90, 20), System.Drawing.Color.FromArgb(40, 10, 5), _
                       System.Drawing.Drawing2D.LinearGradientMode.Vertical)
            End If

            ' 7) Ocean Blue -> Deep Navy
            If OceanBlueToolStripMenuItem.Checked Then
                bgBrush = New System.Drawing.Drawing2D.LinearGradientBrush(rect, _
                       System.Drawing.Color.FromArgb(0, 105, 148), System.Drawing.Color.FromArgb(5, 20, 40), _
                       System.Drawing.Drawing2D.LinearGradientMode.Vertical)
            End If

            ' 8) Steel Gray -> Charcoal
            If SteelGrayToolStripMenuItem.Checked Then
                bgBrush = New System.Drawing.Drawing2D.LinearGradientBrush(rect, _
                       System.Drawing.Color.FromArgb(100, 110, 120), System.Drawing.Color.FromArgb(25, 25, 30), _
                       System.Drawing.Drawing2D.LinearGradientMode.Vertical)
            End If

            ' 9) Sunset Pink -> Dark Violet
            If SunsetPinkToolStripMenuItem.Checked Then
                bgBrush = New System.Drawing.Drawing2D.LinearGradientBrush(rect, _
                       System.Drawing.Color.FromArgb(255, 94, 98), System.Drawing.Color.FromArgb(60, 15, 40), _
                       System.Drawing.Drawing2D.LinearGradientMode.Vertical)
            End If

            ' 10) Gold -> Dark Brown
            If GoldBrownToolStripMenuItem.Checked Then
                bgBrush = New System.Drawing.Drawing2D.LinearGradientBrush(rect, _
                       System.Drawing.Color.FromArgb(218, 165, 32), System.Drawing.Color.FromArgb(40, 20, 5), _
                       System.Drawing.Drawing2D.LinearGradientMode.Vertical)
            End If

            ' 11) Cyan -> Deep Teal
            If CyanTealToolStripMenuItem.Checked Then
                bgBrush = New System.Drawing.Drawing2D.LinearGradientBrush(rect, _
                       System.Drawing.Color.FromArgb(0, 180, 180), System.Drawing.Color.FromArgb(0, 40, 50), _
                       System.Drawing.Drawing2D.LinearGradientMode.Vertical)
            End If

            ' 12) Silver -> Black
            If SilverToolStripMenuItem.Checked Then
                bgBrush = New System.Drawing.Drawing2D.LinearGradientBrush(rect, _
                       System.Drawing.Color.FromArgb(200, 200, 200), System.Drawing.Color.FromArgb(20, 20, 20), _
                       System.Drawing.Drawing2D.LinearGradientMode.Vertical)
            End If

            ' (opsional) haluskan transisi dengan Blend — tersedia di .NET 2.0
            Dim b As New System.Drawing.Drawing2D.Blend()
            b.Factors = New Single() {0.0F, 0.7F, 1.0F}
            b.Positions = New Single() {0.0F, 0.6F, 1.0F}
            bgBrush.Blend = b

            e.Graphics.FillRectangle(bgBrush, rect)

            ' (opsional) tambahkan vignette lembut — juga kompatibel .NET 2.0
            Dim gp As New System.Drawing.Drawing2D.GraphicsPath()
            gp.AddEllipse(CSng(-w * 0.1), CSng(-h * 0.05), CSng(w * 1.2), CSng(h * 1.2))
            Using vgBrush As New System.Drawing.Drawing2D.PathGradientBrush(gp)
                vgBrush.CenterColor = System.Drawing.Color.FromArgb(0, 0, 0, 0) ' transparan di tengah
                vgBrush.SurroundColors = New System.Drawing.Color() {System.Drawing.Color.FromArgb(110, 0, 0, 0)} ' tepi gelap lembut
                e.Graphics.FillRectangle(vgBrush, rect)
            End Using

        Finally
            If bgBrush IsNot Nothing Then bgBrush.Dispose()
        End Try

        ' --- margin area ---
        Dim marginLeft As Integer = 55
        Dim marginBottom As Integer = 30
        Dim marginTop As Integer = 10
        Dim marginRight As Integer = 10

        Dim plotWidth As Integer = w - marginLeft - marginRight
        Dim plotHeight As Integer = h - marginTop - marginBottom

        ' --- Grid ---
        Dim gridPen As New Pen(Color.FromArgb(50, 255, 255, 255), 1)
        Dim gridLinesY As Integer = 5
        For i As Integer = 0 To gridLinesY
            Dim y As Integer = marginTop + CInt(i * plotHeight / gridLinesY)
            g.DrawLine(gridPen, marginLeft, y, marginLeft + plotWidth, y)
        Next

        ' --- Axis label Y ---
        Dim fontAxis As New Font("Segoe UI", 8, FontStyle.Regular)
        Dim minVal As Single = 20
        Dim maxVal As Single = 100
        Dim scaleY As Single = plotHeight / (maxVal - minVal)

        For i As Integer = 0 To gridLinesY
            Dim tempC As Single = maxVal - i * (maxVal - minVal) / gridLinesY
            Dim labelText As String

            If isFahrenheit Then
                Dim tempF As Single = (tempC * 9 / 5) + 32
                labelText = tempF.ToString("0") & "°F"
            Else
                labelText = tempC.ToString("0") & "°C"
            End If

            Dim y As Integer = marginTop + CInt(i * plotHeight / gridLinesY)
            g.DrawString(labelText, fontAxis, Brushes.White, 2, y - 6)
        Next

        ' --- Colors untuk core ---
        Dim colors As Color() = {
            Color.DeepSkyBlue, Color.Orange, Color.LimeGreen,
            Color.Violet, Color.Gold, Color.Crimson,
            Color.MediumPurple, Color.Turquoise
        }

        ' --- Legend ---
        Dim legendCols As Integer = If(coreCountForUI > 8, 2, 1)
        Dim legendWidth As Integer = 120
        Dim legendX As Integer = marginLeft + plotWidth - (legendCols * legendWidth) - 10
        Dim legendY As Integer = marginTop + 5

        For core As Integer = 0 To coreCountForUI - 1
            If core >= tempHistory.Count Then Exit For
            Dim col As Integer = core \ 8 ' kolom ke berapa
            Dim row As Integer = core Mod 8
            Dim posX As Integer = legendX + (col * legendWidth)
            Dim posY As Integer = legendY + row * 15

            Dim penLegend As New Pen(colors(core Mod colors.Length), 2)
            g.DrawLine(penLegend, posX, posY, posX + 20, posY)
            g.DrawString("Core #" & (core + 1).ToString(), fontAxis, Brushes.White, posX + 25, posY - 6)
        Next
        ' --- Indikator titik terakhir ---
        Dim usedPositions As New Dictionary(Of Integer, Single) ' untuk simpan posisi Y yang sudah dipakai

        For core As Integer = 0 To coreCountForUI - 1
            If core >= tempHistory.Count Then Exit For
            Dim history As ArrayList = CType(tempHistory(core), ArrayList)
            If history.Count < 2 Then Continue For

            Dim penCore As New Pen(colors(core Mod colors.Length), 2)
            Dim points(history.Count - 1) As PointF

            For i As Integer = 0 To history.Count - 1
                Dim val As Single = CSng(history(i))
                Dim yVal As Single = (val - minVal) * scaleY
                Dim x As Single = marginLeft + CSng(i) * (plotWidth / maxHistory)
                Dim y As Single = marginTop + plotHeight - yVal
                points(i) = New PointF(x, y)
            Next

            g.DrawLines(penCore, points)

            ' --- Hitung nilai terakhir ---
            Dim lastVal As Single = CSng(history(history.Count - 1))
            Dim lastClock As Single = clocksForUI(core)

            ' Konversi suhu
            Dim tempText As String
            If isFahrenheit Then
                tempText = ((lastVal * 9 / 5) + 32).ToString("0.0") & "°F"
            Else
                tempText = lastVal.ToString("0.0") & "°C"
            End If

            ' Konversi clock → Volt/mV langsung dari HeatMonLib
            Dim clockText As String

            If isGHz Then
                ' Mode Volt
                Dim volt As Double = reader.GetCpuVoltages()(core)  ' ambil volt per-core
                clockText = volt.ToString("0.00") & " V"
            Else
                ' Mode mV
                Dim mvolt As Double = reader.GetCpuVoltages_mV()(core)  ' ambil mV per-core
                clockText = mvolt.ToString("0.00") & " mV"
            End If

            ' Format teks final
            Dim labelText As String = tempText & " | " & clockText


            Dim lastPoint As PointF = points(points.Length - 1)
            Dim c As Color = colors(core Mod colors.Length)

            ' --- Lingkaran indikator ---
            g.FillEllipse(Brushes.White, lastPoint.X - 5, lastPoint.Y - 5, 10, 10)
            g.FillEllipse(New SolidBrush(c), lastPoint.X - 4, lastPoint.Y - 4, 8, 8)

            ' --- Atur posisi teks (anti tumpang tindih + auto flip kanan/kiri/atas/bawah) ---
            Dim textSize As SizeF = g.MeasureString(labelText, fontAxis)
            Dim textX As Single = lastPoint.X + 8
            Dim textY As Single = lastPoint.Y - (textSize.Height / 2)

            ' kalau kepentok kanan → geser ke kiri
            If textX + textSize.Width > marginLeft + plotWidth Then
                textX = lastPoint.X - textSize.Width - 8
            End If

            ' kalau kepentok kiri → geser sedikit ke kanan
            If textX < marginLeft Then
                textX = marginLeft + 2
            End If

            ' kalau kepentok atas
            If textY < marginTop Then
                textY = marginTop
            End If

            ' kalau kepentok bawah
            If textY + textSize.Height > marginTop + plotHeight Then
                textY = marginTop + plotHeight - textSize.Height
            End If

            ' cek apakah sudah ada teks di posisi Y yg mirip → anti tumpang tindih
            For Each kvp In usedPositions
                If Math.Abs(textY - kvp.Value) < textSize.Height + 2 Then
                    textY = kvp.Value + textSize.Height + 4 ' geser ke bawah
                End If
            Next
            usedPositions(core) = textY

            ' --- Background semi transparan ---
            Dim bgRect As New RectangleF(textX - 2, textY - 2, textSize.Width + 4, textSize.Height + 4)
            g.FillRectangle(New SolidBrush(Color.FromArgb(160, 30, 30, 30)), bgRect)

            ' --- Gambar teks indikator ---
            g.DrawString(labelText, fontAxis, Brushes.White, textX, textY)
        Next

       
        ' --- Axis line (X dan Y) ---
        Dim axisPen As New Pen(Color.White, 2)
        g.DrawLine(axisPen, marginLeft, marginTop, marginLeft, marginTop + plotHeight)
        g.DrawLine(axisPen, marginLeft, marginTop + plotHeight, marginLeft + plotWidth, marginTop + plotHeight)

        Dim fontInfo As New Font("Segoe UI", 9, FontStyle.Bold)
        Dim textBrush As New SolidBrush(Color.White)

        Dim dtSize As SizeF = g.MeasureString(currentDateTime, fontInfo)
        Dim swSize As SizeF = g.MeasureString(stopwatchText, fontInfo)

        ' Posisi di bawah grafik (tengah bawah)
        Dim dtX As Single = (w - dtSize.Width) / 2
        Dim dtY As Single = h - dtSize.Height - 20

        Dim swX As Single = (w - swSize.Width) / 2
        Dim swY As Single = dtY + dtSize.Height + 2

        ' Background semi-transparan agar terbaca
        Dim bgRectDT As New RectangleF(dtX - 4, dtY - 2, dtSize.Width + 8, dtSize.Height + 4)
        Dim bgRectSW As New RectangleF(swX - 4, swY - 2, swSize.Width + 8, swSize.Height + 4)

        g.FillRectangle(New SolidBrush(Color.FromArgb(160, 30, 30, 30)), bgRectSW)

        'g.DrawString(currentDateTime, fontInfo, textBrush, dtX, dtY)
        g.DrawString(stopwatchText, fontInfo, textBrush, swX, swY)
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Me.ActiveControl = Nothing
        Try
            ' Tentukan lokasi file
            Dim saveDialog As New SaveFileDialog()
            saveDialog.Filter = "Text Report|*.txt"
            saveDialog.Title = "Save Temperature Report"
            saveDialog.FileName = "CPU_Temp_Report_" & DateTime.Now.ToString("yyyyMMdd_HHmmss") & ".txt"

            If saveDialog.ShowDialog() = DialogResult.OK Then
                Using writer As New IO.StreamWriter(saveDialog.FileName, False)
                    writer.WriteLine("===== CPU Temperature Report =====")
                    writer.WriteLine("Date : " & DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"))
                    writer.WriteLine("CPU Name: " & cpuNameForUI)
                    writer.WriteLine("Core Count: " & coreCountForUI & " (" & Label3.Text & ")")
                    writer.WriteLine("")

                    For i As Integer = 0 To coreCountForUI - 1
                        Dim clockVal As Single = clocksForUI(i)
                        Dim tempVal As Single = tempsForUI(i)
                        Dim clockUnit As String = If(isGHz, "GHz", "MHz")
                        Dim tempUnit As String = If(isFahrenheit, "°F", "°C")

                        If isGHz Then clockVal /= 1000
                        If isFahrenheit Then tempVal = tempVal * 9 / 5 + 32

                        writer.WriteLine("Core #" & (i + 1) &
                                         " | Clock: " & clockVal.ToString("0.00") & " " & clockUnit &
                                         " | Temp: " & tempVal.ToString("0.0") & " " & tempUnit)
                    Next

                    writer.WriteLine("")
                    writer.WriteLine("Cooling RPM: " & lblRPM.Text)
                    writer.WriteLine("=================================")
                End Using

                MessageBox.Show("The report has been successfully saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Process.Start(saveDialog.FileName)
            End If

        Catch ex As Exception
            MessageBox.Show("Failed to save report: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Me.ActiveControl = Nothing
        Try
            Dim saveDialog As New SaveFileDialog()
            saveDialog.Filter = "PNG Image|*.png"
            saveDialog.Title = "Save Temperature Graph"
            saveDialog.FileName = "CPU_Temp_Graph_" & DateTime.Now.ToString("yyyyMMdd_HHmmss") & ".png"

            If saveDialog.ShowDialog() = DialogResult.OK Then
                ' Render PictureBox ke bitmap
                Dim bmp As New Bitmap(PictureBox1.Width, PictureBox1.Height)
                PictureBox1.DrawToBitmap(bmp, New Rectangle(0, 0, PictureBox1.Width, PictureBox1.Height))
                bmp.Save(saveDialog.FileName, Imaging.ImageFormat.Png)

                MessageBox.Show("The graph has been saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Process.Start(saveDialog.FileName)
            End If

        Catch ex As Exception
            MessageBox.Show("Failed to save graph:" & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub TextBox1_TextChanged(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub SaveReportTXTToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SaveReportTXTToolStripMenuItem.Click
        Button1.PerformClick()
    End Sub

    Private Sub SaveGraphPNGToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SaveGraphPNGToolStripMenuItem.Click
        Button2.PerformClick()
    End Sub

    Private Sub PictureBox1_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub ShowUnlistedCoreToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ShowUnlistedCoreToolStripMenuItem.Click
        If ShowUnlistedCoreToolStripMenuItem.Checked Then
            ShowUnlistedCoreToolStripMenuItem.Checked = False
        Else
            ShowUnlistedCoreToolStripMenuItem.Checked = True
        End If
    End Sub

    Private Sub StayOnTopToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles StayOnTopToolStripMenuItem.Click
        If StayOnTopToolStripMenuItem.Checked Then
            StayOnTopToolStripMenuItem.Checked = False
            Me.TopMost = False
        Else
            StayOnTopToolStripMenuItem.Checked = True
            Me.TopMost = True
        End If
    End Sub
    Private currentDateTime As String = ""
    Private stopwatchText As String = ""
    Private Sub TimerUI_Tick(sender As System.Object, e As System.EventArgs) Handles TimerUI.Tick
        currentDateTime = DateTime.Now.ToString("dd MMM yyyy | HH:mm:ss")

        Dim elapsed As TimeSpan = DateTime.Now - startTime
        stopwatchText = String.Format("Time: {0:00}:{1:00}:{2:00}", _
                                      elapsed.Hours, elapsed.Minutes, elapsed.Seconds)
        PictureBox1.Invalidate() ' refresh gambar
    End Sub


    Private Sub AboutToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        frmAbout.ShowDialog()
    End Sub

    Private Sub ContentToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ContentToolStripMenuItem.Click
        Try
            Process.Start(System.IO.Path.Combine(Application.StartupPath, "help.txt"))
        Catch ex As Exception
            '
        End Try
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub EnterSerialKeyToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles EnterSerialKeyToolStripMenuItem.Click
        frmSerial.ShowDialog()
    End Sub

    Private Sub ShowGraphToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ShowGraphToolStripMenuItem.Click
        ' Toggle Checked state with shorcut key CTRL + G to ON/OFF
        ShowGraphToolStripMenuItem.Checked = Not ShowGraphToolStripMenuItem.Checked

        If ShowGraphToolStripMenuItem.Checked Then
            ' Graph ON
            GraphThemesToolStripMenuItem.Enabled = True
            Button2.Enabled = True
            SaveGraphPNGToolStripMenuItem.Enabled = True
            Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Sizable
            Me.MaximizeBox = True
            PictureBox1.Visible = True
            Me.Width = 837
            Me.WindowState = FormWindowState.Maximized
        Else
            ' Graph OFF
            GraphThemesToolStripMenuItem.Enabled = False
            Button2.Enabled = False
            SaveGraphPNGToolStripMenuItem.Enabled = False
            Me.FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle
            Me.MaximizeBox = False
            PictureBox1.Visible = False
            Me.Width = 349
            Me.Height = 418
            Me.WindowState = FormWindowState.Normal
        End If
    End Sub

    Private Sub StatusStrip1_ItemClicked(sender As System.Object, e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles StatusStrip1.ItemClicked

    End Sub
End Class