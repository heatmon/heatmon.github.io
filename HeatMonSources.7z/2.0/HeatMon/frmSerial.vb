﻿Imports System.IO
Public Class frmSerial

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Me.ActiveControl = Nothing
        TextBox1.Text = Clipboard.GetText()
    End Sub
    Public Sub CreateBinaryFileNoExt(ByVal fullPathNoExt As String, ByVal data() As Byte)
        Try
            Dim dir As String = Path.GetDirectoryName(fullPathNoExt)
            If Not Directory.Exists(dir) Then
                Directory.CreateDirectory(dir)
            End If

            Dim fs As FileStream = New FileStream(fullPathNoExt, FileMode.Create, FileAccess.Write)
            fs.Write(data, 0, data.Length)
            fs.Close()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Private Sub LinkLabel1_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Try
            Process.Start("mailto:users.ariproject@gmail.com")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Me.ActiveControl = Nothing
        If TextBox1.Text = "ARX-BRD-CHJ-338" Then
            Dim path As String = System.IO.Path.Combine(Application.StartupPath, "reg")

            ' Tentukan panjang data random (misalnya 256 byte)
            Dim length As Integer = 256
            Dim rnd As New Random()
            Dim data(length - 1) As Byte

            ' Isi array dengan angka biner random (0–255)
            For i As Integer = 0 To length - 1
                data(i) = CByte(rnd.Next(0, 256))
            Next

            ' Buat file
            CreateBinaryFileNoExt(path, data)
            MsgBox("Registration successful!" & vbNewLine & "HeatMon is now available for commercial use.", vbExclamation, "Registered!")
            Form1.cekifreg()
            Me.Close()
        Else
            MsgBox("Registration Failed!" & vbNewLine & "Please enter a valid serial key.", vbCritical, "Failed!")
            TextBox1.Clear()
            TextBox1.Focus()
        End If
    End Sub

    Private Sub frmSerial_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Form1.Text = "HeatMon - Personal use only" Then
           '
        ElseIf Form1.Text = "HeatMon - Commercial use" Then
            Button1.Enabled = False
            Button2.Enabled = False
            TextBox1.Enabled = False
            TextBox1.Text = "REGISTERED"
        End If
    End Sub
End Class