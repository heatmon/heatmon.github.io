﻿Imports System.Management

Public Class FanChecker

    Public Shared Function HasFan() As Boolean
        Try
            Dim searcher As New ManagementObjectSearcher("root\CIMV2", "SELECT * FROM Win32_Fan")
            For Each queryObj As ManagementObject In searcher.Get()
                ' Kalau ada data fan terdeteksi, kembalikan True
                If queryObj("ActiveCooling") IsNot Nothing Then
                    Return True
                End If
            Next
        Catch ex As Exception
            ' Kalau ada error WMI, anggap tidak ada fan
            Return False
        End Try
        ' Kalau tidak ada satupun instance Win32_Fan
        Return False
    End Function
End Class
