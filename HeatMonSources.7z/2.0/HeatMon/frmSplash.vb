﻿Public Class frmSplash

    Private Sub frmSplash_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Timer1.Interval = 3000 ' 3 detik
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        Timer1.Stop()
        Me.Hide()
        Form1.Show()
    End Sub
End Class