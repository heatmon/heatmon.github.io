﻿Imports System.Drawing

Public Class frmAbout
    Private dragging As Boolean = False
    Private lastMouseY As Integer
    Private creditText As String() = {
        "HeatMon 1.3",
        "",
        "Programmer:",
        "Ari Sohandri Putra",
        "M Zainudin",
        "",
        "3rd-party libraries:",
        "WinRing(OpenLibSys)",
        "© Noriyuki Miyazaki",
        "",
        "Supporter:",
        "Lalu Saga (UI)",
        "R Fadly (Graph layout)",
        "",
        "© 2025 Ari Project.",
        "All Rights Reserved."
    }

    Private yOffset As Integer
    Private WithEvents tmr As Timer

    Private Sub frmAbout_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BackColor = Color.White
        PictureBox2.BackColor = Color.White

        ' Mulai posisi teks di bawah PictureBox
        yOffset = PictureBox2.Height

        ' Buat timer
        tmr = New Timer() With {
            .Interval = TrackBar1.Value
        }
        tmr.Start()

        ' Status lisensi
        If Form1.Text = "HeatMon - Personal use only" Then
            Label2.Text = "For Personal use only"
        ElseIf Form1.Text = "HeatMon - Commercial use" Then
            Label2.Text = "For Commercial use"
        End If
    End Sub

    Private Sub tmr_Tick(sender As Object, e As EventArgs) Handles tmr.Tick
        yOffset -= 2
        PictureBox2.Invalidate()

        Dim lineSpacing As Integer = PictureBox2.Height \ 10
        If yOffset < -(creditText.Length * lineSpacing) Then
            yOffset = PictureBox2.Height
        End If
    End Sub

    Private Sub PictureBox2_Paint(sender As Object, e As PaintEventArgs) Handles PictureBox2.Paint
        Dim g As Graphics = e.Graphics
        g.Clear(Color.White)

        ' Ukuran font dasar
        Dim baseFontSize As Single = CSng(PictureBox2.Height / 18.0F)
        Dim lineSpacing As Integer = PictureBox2.Height \ 12
        Dim fadeRegion As Integer = CInt(PictureBox2.Height * 0.2)

        For i As Integer = 0 To creditText.Length - 1
            Dim line As String = creditText(i)
            If String.IsNullOrEmpty(line) Then Continue For

            Dim f As Font
            Dim brushColor As Color

            If line.Contains("HeatMon") Then
                f = New Font("Segoe UI", CSng(baseFontSize * 1.6F), FontStyle.Bold)
                brushColor = Color.FromArgb(35, 70, 190)
            ElseIf line.EndsWith(":") Then
                f = New Font("Segoe UI", CSng(baseFontSize * 1.1F), FontStyle.Bold)
                brushColor = Color.FromArgb(60, 60, 60)
            ElseIf line.Contains("©") Then
                f = New Font("Segoe UI", CSng(baseFontSize * 0.9F), FontStyle.Italic)
                brushColor = Color.FromArgb(100, 100, 100)
            Else
                f = New Font("Segoe UI", baseFontSize, FontStyle.Regular)
                brushColor = Color.FromArgb(40, 40, 40)
            End If

            Dim textSize As SizeF = g.MeasureString(line, f)
            Dim x As Single = (PictureBox2.Width - textSize.Width) / 2
            Dim y As Single = yOffset + (i * lineSpacing)

            ' Alpha fade
            Dim alpha As Integer = 255
            If y > PictureBox2.Height - fadeRegion Then
                Dim dist As Integer = PictureBox2.Height - CInt(y)
                alpha = Math.Max(0, Math.Min(255, CInt(255 * dist / fadeRegion)))
            End If
            If y < fadeRegion Then
                Dim dist As Integer = CInt(y)
                alpha = Math.Max(0, Math.Min(alpha, CInt(255 * dist / fadeRegion)))
            End If

            Dim c As Color = Color.FromArgb(alpha, brushColor)

            ' Efek bayangan pada judul
            If line.Contains("HeatMon") Then
                Using shadowBrush As New SolidBrush(Color.FromArgb(alpha \ 2, Color.Gray))
                    g.DrawString(line, f, shadowBrush, x + 2, y + 2)
                End Using
            End If

            Using fadeBrush As New SolidBrush(c)
                g.DrawString(line, f, fadeBrush, x, y)
            End Using

            f.Dispose()
        Next
    End Sub

    Private Sub PictureBox2_MouseDown(sender As Object, e As MouseEventArgs) Handles PictureBox2.MouseDown
        If e.Button = MouseButtons.Left Then
            dragging = True
            lastMouseY = e.Y
            tmr.Stop()
        End If
    End Sub

    Private Sub PictureBox2_MouseMove(sender As Object, e As MouseEventArgs) Handles PictureBox2.MouseMove
        If dragging Then
            Dim delta As Integer = e.Y - lastMouseY
            yOffset += delta
            lastMouseY = e.Y
            PictureBox2.Invalidate()
        End If
    End Sub

    Private Sub PictureBox2_MouseUp(sender As Object, e As MouseEventArgs) Handles PictureBox2.MouseUp
        If dragging Then
            dragging = False
            tmr.Start()
        End If
    End Sub

    Private Sub TrackBar1_Scroll(sender As Object, e As EventArgs) Handles TrackBar1.Scroll
        tmr.Interval = TrackBar1.Value
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Try
            Process.Start(IO.Path.Combine(Application.StartupPath, "license.txt"))
        Catch
        End Try
    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        Try
            Process.Start("mailto:users.ariproject@gmail.com")
        Catch
        End Try
    End Sub
End Class
