﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSplash
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.GradientLabel1 = New HeatMon.GradientLabel()
        Me.GradientLabel2 = New HeatMon.GradientLabel()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'GradientLabel1
        '
        Me.GradientLabel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GradientLabel1.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GradientLabel1.GradientColor1 = System.Drawing.Color.Gainsboro
        Me.GradientLabel1.GradientColor2 = System.Drawing.Color.White
        Me.GradientLabel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.GradientLabel1.Image = Global.HeatMon.My.Resources.Resources.FAVICON
        Me.GradientLabel1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.GradientLabel1.Location = New System.Drawing.Point(0, 0)
        Me.GradientLabel1.Name = "GradientLabel1"
        Me.GradientLabel1.Size = New System.Drawing.Size(351, 76)
        Me.GradientLabel1.TabIndex = 0
        Me.GradientLabel1.Text = "HeatMon 1.3"
        Me.GradientLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GradientLabel2
        '
        Me.GradientLabel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.GradientLabel2.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GradientLabel2.GradientColor1 = System.Drawing.Color.White
        Me.GradientLabel2.GradientColor2 = System.Drawing.Color.Gainsboro
        Me.GradientLabel2.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.GradientLabel2.Location = New System.Drawing.Point(0, 76)
        Me.GradientLabel2.Name = "GradientLabel2"
        Me.GradientLabel2.Size = New System.Drawing.Size(351, 42)
        Me.GradientLabel2.TabIndex = 1
        Me.GradientLabel2.Text = "Loading Data..."
        Me.GradientLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmSplash
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(351, 118)
        Me.ControlBox = False
        Me.Controls.Add(Me.GradientLabel2)
        Me.Controls.Add(Me.GradientLabel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmSplash"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents GradientLabel1 As HeatMon.GradientLabel
    Friend WithEvents GradientLabel2 As HeatMon.GradientLabel
End Class
